"""
不启动浏览器的端到端验证：清空测试库 -> 依次导入4周示例报表 -> 跑总览/关键词对比/标签/建议/导出Excel全流程。
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import glob
import os

from core import db, pipeline
from core.cleaning import parse_and_clean
from core.export_excel import build_excel_export
from core.weekly_report import generate_weekly_report

TEST_DB = Path(__file__).resolve().parent.parent / "data" / "sp_ads_test.db"
if TEST_DB.exists():
    TEST_DB.unlink()
db.DB_PATH = TEST_DB
db.init_db()

STORE, MARKET, PRODUCT = "TestBrand-US", "US", "B0EXAMPLE1"
settings = db.get_settings()
settings["brand_words"] = ["mybrand"]
db.save_settings(settings)
settings = db.get_settings()


class FakeUpload:
    def __init__(self, path):
        self.name = os.path.basename(path)
        self._data = open(path, "rb").read()

    def read(self):
        return self._data


sample_dir = Path(__file__).resolve().parent.parent / "sample_data"
for report_type, pattern in [("search_term", "search_term_week*.csv"), ("targeting", "targeting_week*.csv")]:
    files = sorted(glob.glob(str(sample_dir / pattern)))
    assert files, f"no sample files for {pattern}"
    for f in files:
        parts = os.path.basename(f).replace(".csv", "").split("_")
        period_start, period_end = parts[-2], parts[-1]
        fu = FakeUpload(f)
        result = parse_and_clean(fu, fu.name, report_type, set(settings["brand_words"]))
        assert not result.errors, result.errors
        print(f"[{report_type}] {os.path.basename(f)} rows={result.final_row_count} missing={result.missing_fields} unmapped={result.unmapped_columns}")
        meta = {
            "store": STORE, "marketplace": MARKET, "product": PRODUCT, "report_type": report_type,
            "period_start": period_start, "period_end": period_end, "filename": fu.name,
            "raw_row_count": result.raw_row_count, "final_row_count": result.final_row_count,
            "duplicate_count": result.duplicate_count, "campaign_count": result.campaign_count,
            "search_term_count": result.search_term_count, "targeting_count": result.targeting_count,
            "unmapped_columns": result.unmapped_columns, "missing_fields": result.missing_fields,
        }
        db.save_upload(meta, result.df)

print("\n=== 总览 (targeting优先) ===")
overview = pipeline.compute_overview(STORE, MARKET, PRODUCT, settings)
assert overview, "overview empty"
for k in ["report_source", "current_period", "previous_period", "spend", "prev_spend", "acos", "prev_acos", "avg4_acos"]:
    print(f"  {k}: {overview.get(k)}")

print("\n=== 周度趋势 ===")
trend_df = pipeline.trend_series(STORE, MARKET, PRODUCT)
print(trend_df[["period_label", "spend", "sales", "orders", "acos"]])

for report_type in ("search_term", "targeting"):
    print(f"\n=== 关键词对比 / 标签 / 建议 ({report_type}) ===")
    result = pipeline.run_entity_analysis(STORE, MARKET, PRODUCT, report_type, settings)
    assert result.available, f"{report_type} analysis unavailable"
    df = result.tagged_df
    print(f"  entities: {len(df)}  current={result.current_period} previous={result.previous_period}")
    tag_cols = [c for c in df.columns if c.startswith("tag_")]
    counts = {c: int(df[c].sum()) for c in tag_cols if df[c].sum() > 0}
    print("  tag counts:", counts)
    print("  sample rows:\n", df[["entity_label", "match_type", "clicks", "orders", "acos", "tags_display"]].to_string(index=False))

    recs = result.recommendations_df
    print(f"  recommendations: {len(recs)}")
    if not recs.empty:
        print(recs["动作类型"].value_counts())
        print(recs[["动作类型", "建议对象", "判断原因", "建议动作"]].head(20).to_string(index=False))

    # Excel export sanity check
    excel_bytes = build_excel_export(
        pd_overview := __import__("pandas").DataFrame([{"指标": "花费", "本周": overview.get("spend", 0)}]),
        df, recs,
    )
    assert len(excel_bytes) > 1000
    out_path = Path(__file__).resolve().parent / f"export_test_{report_type}.xlsx"
    with open(out_path, "wb") as f:
        f.write(excel_bytes)
    print(f"  excel export ok -> {out_path} ({len(excel_bytes)} bytes)")

    if report_type == "search_term":
        report_text = generate_weekly_report(overview, df, recs)
        print("\n  --- weekly report preview ---")
        print(report_text[:1500])

print("\nE2E TEST PASSED")
