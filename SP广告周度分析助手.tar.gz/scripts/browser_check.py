import time
from pathlib import Path

from playwright.sync_api import sync_playwright

BASE = "http://localhost:8501"
SAMPLE_DIR = Path(__file__).resolve().parent.parent / "sample_data"

ERRORS_MARKERS = ["Traceback (most recent call last)", "This app has encountered an error", "KeyError", "AttributeError"]


def check_errors(page, label):
    content = page.content()
    for m in ERRORS_MARKERS:
        if m in content:
            page.screenshot(path=f"/tmp/err_{label}.png")
            raise AssertionError(f"[{label}] found error marker '{m}' — screenshot saved")
    print(f"[{label}] OK, no error markers")


def fill_widget(page, testid, label, value, verify=False):
    box = page.locator(f'div[data-testid="{testid}"]', has_text=label)
    inp = box.locator("input").first
    for attempt in range(5):
        inp.click(click_count=3)
        page.keyboard.type(value, delay=60)
        page.wait_for_timeout(400)
        page.keyboard.press("Enter")
        page.wait_for_timeout(400)
        if not verify or inp.input_value() == value:
            return
    raise AssertionError(f"failed to set {label} to {value}, got {inp.input_value()}")


def upload_one(page, store, market, product, start, end, report_type_label, file_path):
    page.goto(BASE, wait_until="networkidle")
    page.wait_for_selector("text=选择数据范围与周期", timeout=15000)

    fill_widget(page, "stTextInput", "店铺名称", store)
    fill_widget(page, "stTextInput", "站点", market)
    fill_widget(page, "stTextInput", "产品 / SKU / ASIN", product)

    date_start = start.replace("-", "/")
    date_end = end.replace("-", "/")
    fill_widget(page, "stDateInput", "数据周期开始日期", date_start, verify=True)
    fill_widget(page, "stDateInput", "数据周期结束日期", date_end, verify=True)

    select_box = page.locator('div[data-testid="stSelectbox"]', has_text="报表类型").locator('div[data-baseweb="select"]')
    select_box.click()
    page.get_by_role("option", name=report_type_label).click()

    page.set_input_files('input[type="file"]', str(file_path))
    time.sleep(1)
    page.get_by_role("button", name="上传并解析").click()
    page.wait_for_selector("text=上传成功", timeout=15000)
    check_errors(page, f"upload_{file_path.name}")


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/opt/pw-browsers/chromium", headless=True)
        page = browser.new_page()

        weeks = [
            ("2026-06-01", "2026-06-07", 1),
            ("2026-06-08", "2026-06-14", 2),
            ("2026-06-15", "2026-06-21", 3),
            ("2026-06-22", "2026-06-28", 4),
        ]
        for start, end, idx in weeks:
            f = list(SAMPLE_DIR.glob(f"search_term_week{idx}_*.csv"))[0]
            upload_one(page, "浏览器测试店铺", "US", "B0EXAMPLE1", start, end,
                       "Search Term Report（搜索词报表）", f)
        for start, end, idx in weeks:
            f = list(SAMPLE_DIR.glob(f"targeting_week{idx}_*.csv"))[0]
            upload_one(page, "浏览器测试店铺", "US", "B0EXAMPLE1", start, end,
                       "Targeting Report（投放报表）", f)

        pages_to_check = [
            "总览看板", "周度趋势", "关键词对比", "新增词", "消失词", "优化建议", "历史复盘", "设置",
        ]
        for name in pages_to_check:
            page.goto(f"{BASE}/{name}", wait_until="networkidle")
            page.wait_for_timeout(2500)
            check_errors(page, name)
            page.screenshot(path=f"/tmp/page_{name}.png", full_page=True)

        # 在关键词对比页做一次导出Excel点击，验证 download_button 出现
        page.goto(f"{BASE}/关键词对比", wait_until="networkidle")
        page.wait_for_timeout(2000)
        page.get_by_role("button", name="导出本次分析为 Excel").click()
        page.wait_for_selector("text=点击下载 Excel 文件", timeout=10000)
        check_errors(page, "关键词对比_导出后")

        # 优化建议页生成周报
        page.goto(f"{BASE}/优化建议", wait_until="networkidle")
        page.wait_for_timeout(2000)
        page.get_by_role("button", name="生成本周文字周报").click()
        page.wait_for_timeout(1500)
        check_errors(page, "优化建议_周报")

        browser.close()
        print("\nALL BROWSER CHECKS PASSED")


if __name__ == "__main__":
    main()
