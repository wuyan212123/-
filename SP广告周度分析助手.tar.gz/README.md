# SP广告周度分析助手

亚马逊美国站 Sponsored Products 广告周度分析工具。上传 Search Term Report / Targeting Report，
按周自动对比、打标签、给优化建议，并支持导出 Excel。第一版只做分析和建议，不接亚马逊 API，不自动改广告。

## 技术栈

Python + Streamlit + pandas + SQLite + Plotly（需求文档中的方案B：优先保证分析逻辑正确、快速可用）。

## 运行方式

```bash
pip install -r requirements.txt
streamlit run app.py
```

浏览器打开 `http://localhost:8501`，首页即「数据上传」页面。

## 使用流程

1. **数据上传**：填写店铺、站点、产品/ASIN、周期起止日期，选择报表类型（Search Term Report /
   Targeting Report），上传 `.xlsx` 或 `.csv` 文件。系统会自动做字段映射、数值清洗、去重合并，
   并提示缺失字段。
2. **总览看板**：查看本周 vs 上周、本周 vs 近4周均值的整体指标（曝光/点击/花费/销售额/订单/
   CTR/CPC/CVR/ACOS/ROAS）。
3. **周度趋势**：查看最近若干周的花费/销售额/ACOS/订单/CTR/CVR/CPC 趋势图。
4. **关键词对比**（核心页面）：逐词查看本周数据、标签、建议动作，支持按广告活动/广告组/匹配类型/
   标签/是否有订单/ACOS范围/点击范围/搜索词类型筛选，支持一键导出 Excel。
5. **新增词 / 消失词**：分组查看本周新增和消失的词，消失词页附排查清单。
6. **优化建议**：按"转Exact / 提竞价 / 降竞价 / 否定 / 检查预算 / 检查Listing"分类展示建议，
   可生成规则文字周报并保存快照。
7. **历史复盘**：查看每次保存的分析快照。
8. **设置**：调整目标ACOS、点击无单阈值、CTR/CVR/CPC/ACOS变化阈值、核心词周期、新品期模式、
   品牌词词表等，所有阈值均可自定义。

## 示例数据

`sample_data/generate_sample_data.py` 会生成 4 周合成的 Search Term / Targeting 报表（覆盖核心词、
浪费词、消失词、新增词、品牌词、ASIN投放等典型场景），用于快速体验功能：

```bash
python sample_data/generate_sample_data.py
```

生成的 CSV 文件在 `sample_data/` 下，可直接在「数据上传」页面依次上传体验。

## 验证脚本（开发用）

- `scripts/e2e_test.py`：不依赖浏览器，跑通"清洗 → 存储 → 对比 → 打标签 → 生成建议 → 导出Excel →
  生成周报"全流程，用于快速验证分析逻辑。
- `scripts/browser_check.py`：用 Playwright 驱动真实浏览器，依次上传示例数据、遍历所有页面并检查
  是否有报错，用于验证 UI 是否正常。

## 架构说明

```
app.py                  # 数据上传首页
pages/                  # Streamlit 多页面
core/
  field_mapping.py      # 报表字段映射表
  cleaning.py           # 文件解析、数值清洗、关键词文本清洗
  db.py                 # SQLite 存储（uploads / ad_rows / settings / analysis_runs）
  metrics.py            # CTR/CPC/CVR/ACOS/ROAS/CPA 计算
  compare.py            # 本周 vs 上周 / 近4周均值 / 近N周趋势窗口
  tagging.py            # 新增词/消失词/变好词/变差词/核心词/浪费词/待观察词标签规则
  recommendations.py    # 转Exact/提竞价/降竞价/否定/加预算/检查Listing 建议规则
  export_excel.py       # 多Sheet Excel 导出
  weekly_report.py      # 规则生成的文字周报
  pipeline.py           # 串联以上模块的分析主流程
  context.py / styling.py  # 跨页面状态与视觉风格
```

## 已知简化 / 后续可扩展项（对应需求文档 P1/P2）

- 总览看板的账户整体指标优先取自 Targeting Report（若未上传则回退 Search Term Report），避免同时
  使用两种报表导致口径混乱；关键词对比等实体级分析按所选报表类型（搜索词 / 投放词）单独跑一遍。
  两个报表本质是同一数据的不同粒度展开，不会重复计相同的花费/点击。
- "本周 vs 近4周均值"的均值 = 本周之前最近4周的平均值（不含本周）；标签规则里的"近4周"（核心词、
  持续浪费词等）= 含本周在内最近4周，用于衡量近期趋势本身。两者语义不同，已在代码注释中说明。
  历史周期不足4周时，均值对比会自动跳过。
- 否定建议第一版按"单个词"给出 Negative Exact / 否定ASIN 建议，暂未实现"多个搜索词共享同一
  词根、建议整体做 Negative Phrase"的聚类判断，需要人工判断是否合并否定。
- 品牌词/竞品词识别依赖「设置」页面手工维护的词表，未做语义识别。
- Campaign Report / Advertised Product Report / Placement Report 尚未接入独立解析（P1/P2），
  预算检查建议目前用 Targeting Report 聚合出的 Campaign 花费趋势替代"预算使用率"。
- 不接亚马逊 Ads API，不自动修改竞价/否定词，所有输出仅为建议，需人工在广告后台执行。
- 历史复盘目前只记录系统自动生成的分析快照（点击"优化建议"页的保存按钮触发），尚未支持记录
  人工的竞价调整动作与效果回填（文档中的 P2 项）。
