"""
生成用于验证程序逻辑的示例 Search Term Report / Targeting Report（4周数据）。
运行：python sample_data/generate_sample_data.py
"""
import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(42)
OUT_DIR = Path(__file__).resolve().parent

CAMPAIGNS = [
    ("Campaign-Auto-WatercolorSet", "Ad Group 1", "auto"),
    ("Campaign-Broad-WatercolorSet", "Ad Group 1", "broad"),
    ("Campaign-Phrase-WatercolorSet", "Ad Group 1", "phrase"),
    ("Campaign-Exact-WatercolorSet", "Ad Group 1", "exact"),
]

# (search_term, targeting) 词库，覆盖：核心词、浪费词、消失词、新增词等场景
CORE_TERMS = ["watercolor paint set", "watercolor paint kit for adults", "artist watercolor set"]
WASTE_TERMS = ["kids paint set", "cheap paint set", "paint set gift"]
DISAPPEAR_TERMS = ["watercolor brush pen set"]  # 只在前几周出现，后面消失
NEW_TERM_LATEST_WEEK = ["watercolor paint set for beginners"]
BRAND_TERM = ["mybrand watercolor set"]
ASIN_TERM = ["b0c1234567"]
WATCH_TERMS = ["travel watercolor set"]

ALL_BASE_TERMS = CORE_TERMS + WASTE_TERMS + BRAND_TERM + ASIN_TERM + WATCH_TERMS


def week_periods(n=4):
    end = date(2026, 6, 28)
    periods = []
    for i in range(n):
        p_end = end - timedelta(days=7 * (n - 1 - i))
        p_start = p_end - timedelta(days=6)
        periods.append((p_start, p_end))
    return periods


def gen_search_term_report(week_idx: int, period_start: date, period_end: date) -> pd.DataFrame:
    rows = []
    terms = list(ALL_BASE_TERMS)
    if week_idx < 3:
        terms += DISAPPEAR_TERMS
    if week_idx == 3:
        terms += NEW_TERM_LATEST_WEEK

    for term in terms:
        campaign_name, ad_group_name, match_type = random.choice(CAMPAIGNS[:3])
        impressions = random.randint(200, 3000)
        if term in CORE_TERMS:
            clicks = random.randint(20, 60)
            orders = random.randint(3, 8)
        elif term in WASTE_TERMS:
            clicks = random.randint(16, 40)
            orders = 0
        elif term in DISAPPEAR_TERMS:
            clicks = random.randint(10, 25)
            orders = random.randint(1, 3)
        elif term in NEW_TERM_LATEST_WEEK:
            clicks = random.randint(6, 12)
            orders = random.randint(1, 2)
        elif term in BRAND_TERM:
            clicks = random.randint(18, 30)
            orders = 0
        elif term in ASIN_TERM:
            clicks = random.randint(18, 30)
            orders = 0
        else:  # watch terms
            clicks = random.randint(1, 4)
            orders = random.randint(0, 1)

        spend = round(clicks * random.uniform(0.5, 1.2), 2)
        sales = round(orders * random.uniform(15, 30), 2)

        rows.append({
            "Start Date": period_start.isoformat(),
            "End Date": period_end.isoformat(),
            "Campaign Name": campaign_name,
            "Ad Group Name": ad_group_name,
            "Match Type": match_type,
            "Targeting": term if match_type != "auto" else "close-match",
            "Customer Search Term": term,
            "Impressions": impressions,
            "Clicks": clicks,
            "Spend": spend,
            "7 Day Total Sales (Any SKU)": sales,
            "7 Day Total Orders (#)": orders,
            "Advertised ASIN": "B0EXAMPLE1",
            "Advertised SKU": "SKU-WATER-001",
        })
    return pd.DataFrame(rows)


def gen_targeting_report(week_idx: int, period_start: date, period_end: date) -> pd.DataFrame:
    st_df = gen_search_term_report(week_idx, period_start, period_end)
    grouped = st_df.groupby(["Campaign Name", "Ad Group Name", "Match Type", "Targeting"], as_index=False).agg({
        "Impressions": "sum", "Clicks": "sum", "Spend": "sum",
        "7 Day Total Sales (Any SKU)": "sum", "7 Day Total Orders (#)": "sum",
    })
    # 额外加一行已存在的 Exact 广告投放（用于验证"转Exact-已存在"分支）
    grouped = pd.concat([grouped, pd.DataFrame([{
        "Campaign Name": "Campaign-Exact-WatercolorSet", "Ad Group Name": "Ad Group 1", "Match Type": "exact",
        "Targeting": "watercolor paint set", "Impressions": 1500, "Clicks": 40, "Spend": 32.0,
        "7 Day Total Sales (Any SKU)": 120.0, "7 Day Total Orders (#)": 5,
    }])], ignore_index=True)
    grouped["Start Date"] = period_start.isoformat()
    grouped["End Date"] = period_end.isoformat()
    grouped["Advertised ASIN"] = "B0EXAMPLE1"
    grouped["Advertised SKU"] = "SKU-WATER-001"
    return grouped


def main():
    periods = week_periods(4)
    for i, (p_start, p_end) in enumerate(periods):
        st_df = gen_search_term_report(i, p_start, p_end)
        tg_df = gen_targeting_report(i, p_start, p_end)
        st_df.to_csv(OUT_DIR / f"search_term_week{i+1}_{p_start}_{p_end}.csv", index=False)
        tg_df.to_csv(OUT_DIR / f"targeting_week{i+1}_{p_start}_{p_end}.csv", index=False)
        print(f"week{i+1}: {p_start} ~ {p_end}  search_term_rows={len(st_df)} targeting_rows={len(tg_df)}")


if __name__ == "__main__":
    main()
