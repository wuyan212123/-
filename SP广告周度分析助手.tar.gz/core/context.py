"""
跨页面共享的 店铺/站点/产品 选择状态（第4.4节要求每次上传/查看都需要指定这些维度）。
"""
import streamlit as st

from core import db


def scope_selector(location=None) -> tuple[str, str, str] | None:
    """在侧边栏渲染 店铺/站点/产品 选择器，返回 (store, marketplace, product) 或 None。"""
    location = location or st.sidebar
    scopes = db.list_scopes()
    location.markdown("### 数据范围")
    if scopes.empty:
        location.info("还没有上传任何数据，请先到「数据上传」页面上传报表。")
        return None

    scopes["label"] = scopes["store"] + " / " + scopes["marketplace"] + " / " + scopes["product"]
    default_idx = 0
    if "scope_label" in st.session_state and st.session_state["scope_label"] in scopes["label"].values:
        default_idx = int(scopes.index[scopes["label"] == st.session_state["scope_label"]][0])

    chosen_label = location.selectbox("店铺 / 站点 / 产品", scopes["label"].tolist(), index=default_idx)
    st.session_state["scope_label"] = chosen_label
    row = scopes[scopes["label"] == chosen_label].iloc[0]
    return row["store"], row["marketplace"], row["product"]


def report_type_selector(location=None) -> str:
    """搜索词分析 vs 投放词分析 的报表类型选择，跨页面共享同一选择。"""
    location = location or st.sidebar
    options = {"search_term": "Search Term Report（搜索词）", "targeting": "Targeting Report（投放词）"}
    default = st.session_state.get("analysis_report_type", "search_term")
    keys = list(options.keys())
    chosen = location.radio(
        "分析粒度", keys, index=keys.index(default), format_func=lambda k: options[k], horizontal=False
    )
    st.session_state["analysis_report_type"] = chosen
    return chosen


def load_settings_cached() -> dict:
    if "settings" not in st.session_state:
        st.session_state["settings"] = db.get_settings()
    return st.session_state["settings"]
