"""
把各个 core 模块串起来的分析主流程，供各页面复用，避免逻辑重复/不一致。
"""
import pandas as pd

from core import compare, db, tagging
from core.cleaning import classify_keyword_type
from core.metrics import BASE_COLS, add_metrics
from core.recommendations import campaign_budget_recommendations, keyword_recommendations

ENTITY_COLS = ["campaign_name", "ad_group_name", "match_type", "keyword_norm"]


def raw_text_field(report_type: str) -> str:
    return "customer_search_term" if report_type == "search_term" else "targeting"


def account_baselines(current_agg_df: pd.DataFrame) -> tuple[float, float]:
    """账户本周平均CTR/CVR，按曝光/点击加权（而不是逐行简单平均，避免小样本词干扰）。"""
    if current_agg_df.empty:
        return 0.0, 0.0
    total_impressions = current_agg_df["impressions"].sum()
    total_clicks = current_agg_df["clicks"].sum()
    total_orders = current_agg_df["orders"].sum()
    ctr = total_clicks / total_impressions if total_impressions > 0 else 0.0
    cvr = total_orders / total_clicks if total_clicks > 0 else 0.0
    return ctr, cvr


class AnalysisResult:
    def __init__(self):
        self.available = False
        self.periods: list[tuple[str, str]] = []
        self.current_period: tuple[str, str] | None = None
        self.previous_period: tuple[str, str] | None = None
        self.tagged_df = pd.DataFrame()
        self.recommendations_df = pd.DataFrame()
        self.account_ctr = 0.0
        self.account_cvr = 0.0
        self.campaign_trend_df = pd.DataFrame()


def run_entity_analysis(
    store: str, marketplace: str, product: str, report_type: str, settings: dict
) -> AnalysisResult:
    result = AnalysisResult()
    ad_rows_all = db.load_all_periods_ad_rows(store, marketplace, product, report_type)
    if ad_rows_all.empty:
        return result

    periods = compare.sorted_periods(ad_rows_all)
    if not periods:
        return result
    current_period = periods[-1]
    prev_period = compare.previous_period(periods, current_period)

    long_df = compare.aggregate_by_period(ad_rows_all, ENTITY_COLS)

    current_df = long_df[
        (long_df["period_start"] == current_period[0]) & (long_df["period_end"] == current_period[1])
    ].drop(columns=["period_start", "period_end"])
    if prev_period:
        previous_df = long_df[
            (long_df["period_start"] == prev_period[0]) & (long_df["period_end"] == prev_period[1])
        ].drop(columns=["period_start", "period_end"])
    else:
        previous_df = pd.DataFrame(columns=current_df.columns)

    avg4_df = compare.baseline_avg_frame(long_df, ENTITY_COLS, periods, current_period, n_weeks=settings.get("core_word_weeks", 4))
    comparison_df = compare.build_comparison_table(current_df, previous_df, avg4_df, ENTITY_COLS)

    window_weeks = settings.get("core_word_weeks", 4)
    trend_df = compare.trend_window_features(long_df, ENTITY_COLS, periods, current_period, window_weeks=window_weeks)
    comparison_df = tagging.merge_trend_features(comparison_df, trend_df, ENTITY_COLS)

    comparison_df["keyword_type"] = comparison_df["keyword_norm"].apply(
        lambda t: classify_keyword_type(t, set(settings.get("brand_words", [])))
    )

    raw_field = raw_text_field(report_type)
    label_lookup = (
        ad_rows_all.sort_values("period_end")
        .groupby(ENTITY_COLS)[raw_field]
        .last()
        .reset_index()
        .rename(columns={raw_field: "entity_label"})
    )
    comparison_df = comparison_df.merge(label_lookup, on=ENTITY_COLS, how="left")
    comparison_df["entity_label"] = comparison_df["entity_label"].fillna(comparison_df["keyword_norm"])

    account_ctr, account_cvr = account_baselines(current_df)
    tagged_df = tagging.compute_tags(comparison_df, settings, account_ctr, account_cvr)

    existing_exact = set(
        current_df.loc[current_df["match_type"].astype(str).str.lower() == "exact", "keyword_norm"]
    )
    recommendations_df = keyword_recommendations(
        tagged_df, settings, "entity_label", account_ctr, account_cvr, existing_exact
    )

    campaign_long = compare.aggregate_by_period(ad_rows_all, ["campaign_name"])
    budget_recs = campaign_budget_recommendations(campaign_long, settings)
    recommendations_df = pd.concat([recommendations_df, budget_recs], ignore_index=True)

    result.available = True
    result.periods = periods
    result.current_period = current_period
    result.previous_period = prev_period
    result.tagged_df = tagged_df
    result.recommendations_df = recommendations_df
    result.account_ctr = account_ctr
    result.account_cvr = account_cvr
    result.campaign_trend_df = campaign_long
    return result


def _period_totals(ad_rows_all: pd.DataFrame, period: tuple[str, str]) -> dict:
    sub = ad_rows_all[(ad_rows_all["period_start"] == period[0]) & (ad_rows_all["period_end"] == period[1])]
    sums = sub[BASE_COLS].sum()
    return add_metrics(sums.to_frame().T).iloc[0].to_dict()


def compute_overview(store: str, marketplace: str, product: str, settings: dict) -> dict:
    """总览看板数据源：优先 Targeting Report，其次 Search Term Report（账户整体口径，不分实体）。"""
    for report_type in ("targeting", "search_term"):
        ad_rows_all = db.load_all_periods_ad_rows(store, marketplace, product, report_type)
        if ad_rows_all.empty:
            continue
        periods = compare.sorted_periods(ad_rows_all)
        if not periods:
            continue
        current_period = periods[-1]
        prev_period = compare.previous_period(periods, current_period)

        cur_totals = _period_totals(ad_rows_all, current_period)
        if prev_period:
            prev_totals = _period_totals(ad_rows_all, prev_period)
        else:
            prev_totals = {k: 0.0 for k in cur_totals}

        idx = periods.index(current_period)
        n = settings.get("core_word_weeks", 4)
        window = periods[max(0, idx - n): idx]
        if window:
            mask = ad_rows_all.apply(lambda r: (r["period_start"], r["period_end"]) in window, axis=1)
            window_sums = ad_rows_all[mask][BASE_COLS].sum() / len(window)
            avg4_totals = add_metrics(window_sums.to_frame().T).iloc[0].to_dict()
        else:
            avg4_totals = {}

        overview = {"report_source": report_type, "current_period": current_period, "previous_period": prev_period}
        overview.update(cur_totals)
        overview.update({f"prev_{k}": v for k, v in prev_totals.items()})
        overview.update({f"avg4_{k}": v for k, v in avg4_totals.items()})
        overview["periods"] = periods
        return overview
    return {}


def trend_series(store: str, marketplace: str, product: str) -> pd.DataFrame:
    """全部周期的账户整体指标，用于周度趋势图。优先 Targeting Report。"""
    for report_type in ("targeting", "search_term"):
        ad_rows_all = db.load_all_periods_ad_rows(store, marketplace, product, report_type)
        if ad_rows_all.empty:
            continue
        periods = compare.sorted_periods(ad_rows_all)
        rows = []
        for p in periods:
            totals = _period_totals(ad_rows_all, p)
            totals["period_start"], totals["period_end"] = p
            totals["period_label"] = f"{p[0]}~{p[1]}"
            rows.append(totals)
        df = pd.DataFrame(rows)
        df["report_source"] = report_type
        return df
    return pd.DataFrame()
