"""
统一的视觉风格：简洁、整洁、直观，偏运营后台工具（第3节设计风格要求）。
"""
import streamlit as st

COLOR_GOOD = "#16a34a"    # 绿色：健康/增长
COLOR_WATCH = "#f59e0b"   # 橙色：观察
COLOR_RISK = "#dc2626"    # 红色：风险
COLOR_NEUTRAL = "#2563eb"  # 蓝色：中性/信息

CSS = """
<style>
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
.block-container {padding-top: 1.5rem; max-width: 1200px;}

.kpi-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 14px 16px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.kpi-title {font-size: 13px; color: #6b7280; margin-bottom: 4px;}
.kpi-value {font-size: 22px; font-weight: 700; color: #111827;}
.kpi-sub {font-size: 12px; margin-top: 4px;}

.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 600;
    margin-right: 4px;
    color: white;
}
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def badge(text: str, color: str) -> str:
    return f'<span class="badge" style="background:{color}">{text}</span>'


def direction_color(pct, good_when: str) -> str:
    """good_when: 'up' 表示数值越大越好, 'down' 表示数值越小越好"""
    if pct is None:
        return COLOR_WATCH
    if good_when == "up":
        return COLOR_GOOD if pct >= 0 else COLOR_RISK
    return COLOR_GOOD if pct <= 0 else COLOR_RISK


def kpi_card(title: str, value_str: str, sub_html: str = ""):
    st.markdown(
        f"""
        <div class="kpi-card">
            <div class="kpi-title">{title}</div>
            <div class="kpi-value">{value_str}</div>
            <div class="kpi-sub">{sub_html}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
