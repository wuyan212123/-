"""
关键词/搜索词标签体系，对应需求文档第 8 节。

输入: build_comparison_table() 的输出 merge trend_window_features() 之后的 DataFrame。
输出: 在原 df 上新增各标签布尔列 + 一个汇总的 tags(list[str]) 列。

标签之间不是互斥关系（一个词可以同时是"表现变差词"和"浪费词"）。
"""
import numpy as np
import pandas as pd

TREND_FEATURE_DEFAULTS = {
    "weeks_present": 0,
    "weeks_with_orders": 0,
    "orders_sum_window": 0.0,
    "spend_sum_window": 0.0,
    "sales_sum_window": 0.0,
    "acos_window": 0.0,
    "consecutive_waste_weeks": 0,
}


def merge_trend_features(comparison_df: pd.DataFrame, trend_df: pd.DataFrame, entity_cols: list[str]) -> pd.DataFrame:
    if trend_df.empty:
        df = comparison_df.copy()
        for c, default in TREND_FEATURE_DEFAULTS.items():
            df[c] = default
        return df
    df = comparison_df.merge(trend_df, on=entity_cols, how="left")
    for c, default in TREND_FEATURE_DEFAULTS.items():
        if c not in df.columns:
            df[c] = default
        df[c] = df[c].fillna(default)
    return df


def compute_tags(
    df: pd.DataFrame,
    settings: dict,
    account_ctr: float,
    account_cvr: float,
) -> pd.DataFrame:
    df = df.copy()
    target_acos = settings["target_acos"]
    high_acos_mult = settings["high_acos_multiplier"]
    click_no_order_th = settings["click_no_order_threshold"]
    min_clicks = settings["min_clicks_for_judgement"]
    target_cpa = settings.get("target_cpa")
    ctr_improve_th = settings["ctr_improve_threshold"]
    cvr_improve_th = settings["cvr_improve_threshold"]
    acos_worsen_th = settings["acos_worsen_threshold"]
    cpc_rise_th = settings["cpc_rise_threshold"]

    def col(name, default=0.0):
        return df[name] if name in df.columns else pd.Series(default, index=df.index)

    impressions, clicks, orders, spend = col("impressions"), col("clicks"), col("orders"), col("spend")
    prev_impressions, prev_clicks = col("prev_impressions"), col("prev_clicks")
    prev_orders, prev_spend = col("prev_orders"), col("prev_spend")
    ctr, cvr, cpc, acos = col("ctr"), col("cvr"), col("cpc"), col("acos")
    prev_ctr, prev_cvr, prev_acos = col("prev_ctr"), col("prev_cvr"), col("prev_acos")

    ctr_change_pct = col("ctr_change_pct", np.nan)
    cvr_change_pct = col("cvr_change_pct", np.nan)
    acos_change_pct = col("acos_change_pct", np.nan)
    cpc_change_pct = col("cpc_change_pct", np.nan)
    spend_change_pct = col("spend_change_pct", np.nan)

    weeks_with_orders = col("weeks_with_orders", 0)
    orders_sum_window = col("orders_sum_window", 0.0)
    acos_window = col("acos_window", 0.0)
    consecutive_waste_weeks = col("consecutive_waste_weeks", 0)

    current_active = (impressions > 0) | (clicks > 0) | (orders > 0)
    prev_active = (prev_impressions > 0) | (prev_clicks > 0) | (prev_orders > 0)

    # ---- 8.1 新增词 ----
    df["tag_new_impression"] = (~prev_active) & current_active & (impressions > 0) & (clicks == 0)
    df["tag_new_click"] = (~prev_active) & current_active & (clicks > 0)
    df["tag_new_order"] = (~prev_active) & current_active & (orders > 0)
    df["tag_new_high_potential"] = (
        (~prev_active)
        & current_active
        & (clicks >= min_clicks)
        & ((ctr >= account_ctr) | (cvr >= account_cvr))
        & ((orders >= 1) | (cvr >= account_cvr))
    )
    df["tag_is_new"] = (~prev_active) & current_active

    # ---- 8.2 消失词 ----
    hist_had_orders = orders_sum_window > 0
    df["tag_disappeared_normal"] = (~current_active) & prev_active
    df["tag_disappeared_key"] = (~current_active) & hist_had_orders
    df["tag_disappeared_high_value"] = (
        (~current_active) & hist_had_orders & ((acos_window <= target_acos) | (prev_cvr >= account_cvr))
    )
    df["tag_is_disappeared"] = (~current_active) & prev_active

    both_present = current_active & prev_active

    # ---- 8.3 表现变好词 ----
    df["tag_ctr_up"] = both_present & ctr_change_pct.notna() & (ctr_change_pct >= ctr_improve_th)
    df["tag_cvr_up"] = both_present & cvr_change_pct.notna() & (cvr_change_pct >= cvr_improve_th)
    df["tag_orders_up"] = both_present & (orders > prev_orders)
    df["tag_acos_improved"] = both_present & (orders > 0) & (acos < prev_acos)
    df["tag_scalable"] = (weeks_with_orders >= 2) & (acos <= target_acos) & (orders > 0)

    # ---- 8.4 表现变差词 ----
    df["tag_ctr_down"] = both_present & (impressions >= prev_impressions) & (ctr < prev_ctr)
    df["tag_cvr_down"] = both_present & (clicks >= prev_clicks) & (cvr < prev_cvr)
    df["tag_cpc_up"] = both_present & cpc_change_pct.notna() & (cpc_change_pct >= cpc_rise_th)
    df["tag_acos_worsened"] = (
        both_present & (acos > target_acos) & acos_change_pct.notna() & (acos_change_pct >= acos_worsen_th)
    )
    df["tag_spend_wasted"] = both_present & (spend > prev_spend) & (orders == 0)
    df["tag_declining_converter"] = hist_had_orders & (prev_orders > 0) & ((orders < prev_orders) | (orders == 0))

    # ---- 8.5 核心词 ----
    core_weeks_required = settings.get("core_word_weeks", 4)
    min_order_weeks = 3 if core_weeks_required >= 4 else max(2, core_weeks_required - 1)
    df["tag_core"] = (
        (weeks_with_orders >= min_order_weeks) & (orders_sum_window >= 3) & (acos_window <= target_acos)
    )

    # ---- 8.6 浪费词 ----
    df["tag_click_waste"] = (clicks >= click_no_order_th) & (orders == 0)
    if target_cpa is not None:
        df["tag_spend_waste_cpa"] = (spend >= target_cpa) & (orders == 0)
    else:
        df["tag_spend_waste_cpa"] = False
    df["tag_persistent_waste"] = consecutive_waste_weeks >= 2
    df["tag_high_acos_loss"] = (orders > 0) & (acos > target_acos * high_acos_mult)

    # ---- 8.7 待观察词 ----
    df["tag_watch"] = current_active & ((clicks < min_clicks) | (impressions < 100) | (orders == 1))

    tag_label_map = {
        "tag_new_impression": "新增曝光词",
        "tag_new_click": "新增点击词",
        "tag_new_order": "新增成交词",
        "tag_new_high_potential": "新增高潜力词",
        "tag_disappeared_normal": "普通消失词",
        "tag_disappeared_key": "重点消失词",
        "tag_disappeared_high_value": "高价值消失词",
        "tag_ctr_up": "CTR提升词",
        "tag_cvr_up": "CVR提升词",
        "tag_orders_up": "订单增长词",
        "tag_acos_improved": "ACOS改善词",
        "tag_scalable": "可放大词",
        "tag_ctr_down": "CTR下降词",
        "tag_cvr_down": "CVR下降词",
        "tag_cpc_up": "CPC上涨词",
        "tag_acos_worsened": "ACOS恶化词",
        "tag_spend_wasted": "花费浪费词",
        "tag_declining_converter": "衰退成交词",
        "tag_core": "核心词",
        "tag_click_waste": "点击浪费词",
        "tag_spend_waste_cpa": "花费浪费词(CPA)",
        "tag_persistent_waste": "持续浪费词",
        "tag_high_acos_loss": "高ACOS亏损词",
        "tag_watch": "待观察词",
    }

    def _row_tags(row):
        return [label for col_name, label in tag_label_map.items() if row.get(col_name)]

    df["tags"] = df.apply(_row_tags, axis=1)
    df["tags_display"] = df["tags"].apply(lambda ts: "、".join(ts) if ts else "")
    return df
