"""
字段映射表：把亚马逊广告报表(英文/中文、不同版本)的列名，统一映射为标准字段名。

标准字段定义见需求文档第 6.1 节。
"""

# 标准字段 -> 可能出现的原始列名（不区分大小写、忽略首尾空格）
FIELD_ALIASES: dict[str, list[str]] = {
    "date_range_start": ["start date", "date range start", "开始日期", "reporting range start"],
    "date_range_end": ["end date", "date range end", "结束日期", "reporting range end"],
    "portfolio_name": ["portfolio name", "portfolio", "广告组合", "广告组合名称"],
    "campaign_name": ["campaign name", "campaign", "广告活动名称", "广告活动"],
    "ad_group_name": ["ad group name", "ad group", "广告组名称", "广告组"],
    "match_type": ["match type", "匹配类型"],
    "targeting": ["targeting", "keyword text", "投放", "投放对象", "关键词"],
    "search_term": ["search term", "搜索词"],
    "customer_search_term": [
        "customer search term",
        "顾客搜索词",
        "客户搜索词",
        "search term",
        "搜索词",
    ],
    "advertised_asin": ["advertised asin", "asin", "推广的asin", "广告asin"],
    "sku": ["advertised sku", "sku", "推广的sku"],
    "impressions": ["impressions", "曝光量", "展示量"],
    "clicks": ["clicks", "点击量", "点击次数"],
    "spend": ["spend", "cost", "花费", "广告花费"],
    "sales": [
        "sales",
        "7 day total sales",
        "7 day total sales (any sku)",
        "7 day total sales(any sku)",
        "总销售额",
        "销售额",
        "7天总销售额",
    ],
    "orders": [
        "orders",
        "purchases",
        "7 day total orders (#)",
        "7 day total orders(#)",
        "订单量",
        "订单数",
        "7天总订单量(#)",
    ],
}

# 每种报表类型必须存在的标准字段（缺失需要提醒用户）
REQUIRED_FIELDS = {
    "search_term": [
        "campaign_name",
        "ad_group_name",
        "match_type",
        "targeting",
        "customer_search_term",
        "impressions",
        "clicks",
        "spend",
        "sales",
        "orders",
    ],
    "targeting": [
        "campaign_name",
        "ad_group_name",
        "match_type",
        "targeting",
        "impressions",
        "clicks",
        "spend",
        "sales",
        "orders",
    ],
}


def _normalize_header(h: str) -> str:
    return str(h).strip().lower().replace("_", " ")


def build_rename_map(columns: list[str]) -> tuple[dict[str, str], list[str]]:
    """
    根据原始列名列表，构建 原始列名 -> 标准字段名 的映射。
    返回 (rename_map, unmapped_original_columns)
    """
    normalized_lookup: dict[str, str] = {}
    for std_field, aliases in FIELD_ALIASES.items():
        for alias in aliases:
            normalized_lookup.setdefault(_normalize_header(alias), std_field)

    rename_map: dict[str, str] = {}
    unmapped: list[str] = []
    for col in columns:
        key = _normalize_header(col)
        if key in normalized_lookup:
            rename_map[col] = normalized_lookup[key]
        else:
            unmapped.append(col)
    return rename_map, unmapped


def missing_required_fields(mapped_fields: set[str], report_type: str) -> list[str]:
    required = REQUIRED_FIELDS.get(report_type, [])
    return [f for f in required if f not in mapped_fields]
