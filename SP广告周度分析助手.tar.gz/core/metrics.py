"""
核心指标计算，对应需求文档第 5 节。所有比率指标都做除零保护。
"""
import numpy as np
import pandas as pd

BASE_COLS = ["impressions", "clicks", "spend", "sales", "orders"]


def add_metrics(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for c in BASE_COLS:
        if c not in df.columns:
            df[c] = 0.0
        df[c] = df[c].fillna(0.0)

    df["ctr"] = np.where(df["impressions"] > 0, df["clicks"] / df["impressions"], 0.0)
    df["cpc"] = np.where(df["clicks"] > 0, df["spend"] / df["clicks"], 0.0)
    df["cvr"] = np.where(df["clicks"] > 0, df["orders"] / df["clicks"], 0.0)
    df["acos"] = np.where(df["sales"] > 0, df["spend"] / df["sales"], np.where(df["spend"] > 0, np.inf, 0.0))
    df["roas"] = np.where(df["spend"] > 0, df["sales"] / df["spend"], 0.0)
    df["cpa"] = np.where(df["orders"] > 0, df["spend"] / df["orders"], np.where(df["spend"] > 0, np.inf, 0.0))
    return df


def aggregate(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    """按指定维度聚合基础指标并重新计算比率指标。"""
    if df.empty:
        return add_metrics(pd.DataFrame(columns=group_cols + BASE_COLS))
    agg = df.groupby(group_cols, dropna=False, as_index=False)[BASE_COLS].sum()
    return add_metrics(agg)
