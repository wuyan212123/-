"""
SQLite 数据存储层。对应需求文档第 12 节。
"""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import pandas as pd

DB_PATH = Path(__file__).resolve().parent.parent / "data" / "sp_ads.db"

DEFAULT_SETTINGS = {
    "target_acos": 0.35,
    "high_acos_multiplier": 1.5,
    "click_no_order_threshold": 15,
    "min_clicks_for_judgement": 5,
    "target_cpa": None,
    "ctr_improve_threshold": 0.30,
    "cvr_improve_threshold": 0.30,
    "acos_worsen_threshold": 0.30,
    "cpc_rise_threshold": 0.20,
    "core_word_weeks": 4,
    "new_product_mode": False,
    "brand_words": [],
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS uploads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    store TEXT NOT NULL,
    marketplace TEXT NOT NULL,
    product TEXT NOT NULL,
    report_type TEXT NOT NULL,
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    filename TEXT,
    uploaded_at TEXT,
    raw_row_count INTEGER,
    final_row_count INTEGER,
    duplicate_count INTEGER,
    campaign_count INTEGER,
    search_term_count INTEGER,
    targeting_count INTEGER,
    unmapped_columns TEXT,
    missing_fields TEXT
);

CREATE TABLE IF NOT EXISTS ad_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    upload_id INTEGER NOT NULL,
    store TEXT NOT NULL,
    marketplace TEXT NOT NULL,
    product TEXT NOT NULL,
    report_type TEXT NOT NULL,
    period_start TEXT NOT NULL,
    period_end TEXT NOT NULL,
    portfolio_name TEXT,
    campaign_name TEXT,
    ad_group_name TEXT,
    match_type TEXT,
    targeting TEXT,
    search_term TEXT,
    customer_search_term TEXT,
    keyword_norm TEXT,
    keyword_type TEXT,
    advertised_asin TEXT,
    sku TEXT,
    impressions REAL,
    clicks REAL,
    spend REAL,
    sales REAL,
    orders REAL
);

CREATE INDEX IF NOT EXISTS idx_ad_rows_scope
    ON ad_rows (store, marketplace, product, report_type, period_start, period_end);

CREATE TABLE IF NOT EXISTS analysis_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    store TEXT,
    marketplace TEXT,
    product TEXT,
    period_start TEXT,
    period_end TEXT,
    created_at TEXT,
    summary_json TEXT
);
"""


@contextmanager
def get_conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        cur = conn.execute("SELECT COUNT(*) FROM settings")
        if cur.fetchone()[0] == 0:
            for k, v in DEFAULT_SETTINGS.items():
                conn.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?)",
                    (k, json.dumps(v)),
                )


def get_settings() -> dict:
    with get_conn() as conn:
        rows = conn.execute("SELECT key, value FROM settings").fetchall()
    settings = dict(DEFAULT_SETTINGS)
    for k, v in rows:
        try:
            settings[k] = json.loads(v)
        except (json.JSONDecodeError, TypeError):
            settings[k] = v
    return settings


def save_settings(settings: dict):
    with get_conn() as conn:
        for k, v in settings.items():
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (k, json.dumps(v)),
            )


def list_scopes() -> pd.DataFrame:
    """返回所有已上传数据涉及的 店铺/站点/产品 组合。"""
    with get_conn() as conn:
        return pd.read_sql(
            "SELECT DISTINCT store, marketplace, product FROM uploads ORDER BY store, marketplace, product",
            conn,
        )


def list_periods(store: str, marketplace: str, product: str, report_type: str | None = None) -> pd.DataFrame:
    query = (
        "SELECT DISTINCT period_start, period_end FROM uploads "
        "WHERE store=? AND marketplace=? AND product=?"
    )
    params = [store, marketplace, product]
    if report_type:
        query += " AND report_type=?"
        params.append(report_type)
    query += " ORDER BY period_end DESC"
    with get_conn() as conn:
        return pd.read_sql(query, conn, params=params)


def save_upload(meta: dict, df: pd.DataFrame) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """
            INSERT INTO uploads
                (store, marketplace, product, report_type, period_start, period_end,
                 filename, uploaded_at, raw_row_count, final_row_count, duplicate_count,
                 campaign_count, search_term_count, targeting_count, unmapped_columns, missing_fields)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                meta["store"],
                meta["marketplace"],
                meta["product"],
                meta["report_type"],
                meta["period_start"],
                meta["period_end"],
                meta["filename"],
                datetime.now().isoformat(timespec="seconds"),
                meta["raw_row_count"],
                meta["final_row_count"],
                meta["duplicate_count"],
                meta["campaign_count"],
                meta["search_term_count"],
                meta["targeting_count"],
                json.dumps(meta["unmapped_columns"], ensure_ascii=False),
                json.dumps(meta["missing_fields"], ensure_ascii=False),
            ),
        )
        upload_id = cur.lastrowid

        df = df.copy()
        df["upload_id"] = upload_id
        df["store"] = meta["store"]
        df["marketplace"] = meta["marketplace"]
        df["product"] = meta["product"]
        df["report_type"] = meta["report_type"]
        df["period_start"] = meta["period_start"]
        df["period_end"] = meta["period_end"]

        cols = [
            "upload_id", "store", "marketplace", "product", "report_type",
            "period_start", "period_end", "portfolio_name", "campaign_name",
            "ad_group_name", "match_type", "targeting", "search_term",
            "customer_search_term", "keyword_norm", "keyword_type",
            "advertised_asin", "sku", "impressions", "clicks", "spend", "sales", "orders",
        ]
        for c in cols:
            if c not in df.columns:
                df[c] = "" if c not in ("impressions", "clicks", "spend", "sales", "orders", "upload_id") else 0
        df[cols].to_sql("ad_rows", conn, if_exists="append", index=False)
        return upload_id


def load_ad_rows(
    store: str,
    marketplace: str,
    product: str,
    report_type: str,
    period_start: str | None = None,
    period_end: str | None = None,
) -> pd.DataFrame:
    query = (
        "SELECT * FROM ad_rows WHERE store=? AND marketplace=? AND product=? AND report_type=?"
    )
    params = [store, marketplace, product, report_type]
    if period_start and period_end:
        query += " AND period_start=? AND period_end=?"
        params += [period_start, period_end]
    with get_conn() as conn:
        return pd.read_sql(query, conn, params=params)


def load_all_periods_ad_rows(store: str, marketplace: str, product: str, report_type: str) -> pd.DataFrame:
    with get_conn() as conn:
        return pd.read_sql(
            "SELECT * FROM ad_rows WHERE store=? AND marketplace=? AND product=? AND report_type=?",
            conn,
            params=[store, marketplace, product, report_type],
        )


def list_uploads(store: str | None = None) -> pd.DataFrame:
    query = "SELECT * FROM uploads"
    params = []
    if store:
        query += " WHERE store=?"
        params.append(store)
    query += " ORDER BY uploaded_at DESC"
    with get_conn() as conn:
        return pd.read_sql(query, conn, params=params)


def _json_default(o):
    if hasattr(o, "item"):  # numpy scalar
        return o.item()
    return str(o)


def save_analysis_run(store, marketplace, product, period_start, period_end, summary: dict) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """
            INSERT INTO analysis_runs (store, marketplace, product, period_start, period_end, created_at, summary_json)
            VALUES (?,?,?,?,?,?,?)
            """,
            (
                store, marketplace, product, period_start, period_end,
                datetime.now().isoformat(timespec="seconds"),
                json.dumps(summary, ensure_ascii=False, default=_json_default),
            ),
        )
        return cur.lastrowid


def list_analysis_runs(store: str, marketplace: str, product: str) -> pd.DataFrame:
    with get_conn() as conn:
        return pd.read_sql(
            "SELECT * FROM analysis_runs WHERE store=? AND marketplace=? AND product=? ORDER BY created_at DESC",
            conn,
            params=[store, marketplace, product],
        )
