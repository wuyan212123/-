"""
规则生成的文字周报，对应需求文档第 17 节。第一版不接AI，纯规则拼句。
"""
import pandas as pd


def _fmt_pct(v) -> str:
    if v is None or pd.isna(v):
        return "N/A"
    return f"{v:+.1%}"


def _fmt_money(v) -> str:
    return f"${v:,.2f}"


def generate_weekly_report(overview: dict, tagged_df: pd.DataFrame, recommendations_df: pd.DataFrame) -> str:
    lines = []

    lines.append("## 1. 本周广告整体表现")
    spend, prev_spend = overview.get("spend", 0), overview.get("prev_spend", 0)
    sales, prev_sales = overview.get("sales", 0), overview.get("prev_sales", 0)
    acos, prev_acos = overview.get("acos", 0), overview.get("prev_acos", 0)
    orders, prev_orders = overview.get("orders", 0), overview.get("prev_orders", 0)
    trend = "变好" if (acos <= prev_acos and sales >= prev_sales) else ("变差" if acos > prev_acos and sales < prev_sales else "喜忧参半")
    lines.append(
        f"本周花费{_fmt_money(spend)}（上周{_fmt_money(prev_spend)}），销售额{_fmt_money(sales)}（上周{_fmt_money(prev_sales)}），"
        f"订单{orders:.0f}单（上周{prev_orders:.0f}单），ACOS {acos:.1%}（上周{prev_acos:.1%}）。整体判断：本周广告表现**{trend}**。"
    )

    lines.append("\n## 2. 本周主要增长来源")
    improved = tagged_df[
        tagged_df.get("tag_orders_up", False) | tagged_df.get("tag_acos_improved", False)
    ] if not tagged_df.empty else tagged_df
    if not improved.empty:
        top = improved.sort_values("orders", ascending=False).head(5)
        for _, r in top.iterrows():
            lines.append(f"- {r.get('entity_label','')}：订单{r.get('orders',0):.0f}单，ACOS {r.get('acos',0):.1%}")
    else:
        lines.append("- 本周没有明显的增长来源。")

    lines.append("\n## 3. 本周主要拖累因素")
    worsened = tagged_df[
        tagged_df.get("tag_acos_worsened", False) | tagged_df.get("tag_spend_wasted", False)
    ] if not tagged_df.empty else tagged_df
    if not worsened.empty:
        top = worsened.sort_values("spend", ascending=False).head(5)
        for _, r in top.iterrows():
            lines.append(f"- {r.get('entity_label','')}：花费{_fmt_money(r.get('spend',0))}，ACOS {r.get('acos',0):.1%}")
    else:
        lines.append("- 本周没有明显的拖累因素。")

    lines.append("\n## 4. 新增高潜力搜索词")
    new_hp = tagged_df[tagged_df.get("tag_new_high_potential", False)] if not tagged_df.empty else tagged_df
    if not new_hp.empty:
        for _, r in new_hp.head(10).iterrows():
            lines.append(f"- {r.get('entity_label','')}（点击{r.get('clicks',0):.0f}，CTR{r.get('ctr',0):.2%}）")
    else:
        lines.append("- 本周无新增高潜力词。")

    lines.append("\n## 5. 需要关注的消失词")
    disappeared = tagged_df[
        tagged_df.get("tag_disappeared_key", False) | tagged_df.get("tag_disappeared_high_value", False)
    ] if not tagged_df.empty else tagged_df
    if not disappeared.empty:
        for _, r in disappeared.head(10).iterrows():
            lines.append(f"- {r.get('entity_label','')}：历史近4周订单{r.get('orders_sum_window',0):.0f}单，本周无数据，请排查预算/竞价/否定/断货")
    else:
        lines.append("- 本周无重点消失词。")

    lines.append("\n## 6. 表现变差的关键词")
    bad = tagged_df[
        tagged_df.get("tag_ctr_down", False) | tagged_df.get("tag_cvr_down", False) | tagged_df.get("tag_acos_worsened", False)
    ] if not tagged_df.empty else tagged_df
    if not bad.empty:
        for _, r in bad.head(10).iterrows():
            lines.append(f"- {r.get('entity_label','')}：{r.get('tags_display','')}")
    else:
        lines.append("- 本周无明显表现变差的词。")

    lines.append("\n## 7. 浪费花费关键词")
    waste = tagged_df[
        tagged_df.get("tag_click_waste", False) | tagged_df.get("tag_persistent_waste", False)
    ] if not tagged_df.empty else tagged_df
    if not waste.empty:
        total_waste_spend = waste["spend"].sum()
        lines.append(f"共{len(waste)}个词符合浪费特征，累计花费{_fmt_money(total_waste_spend)}：")
        for _, r in waste.sort_values("spend", ascending=False).head(10).iterrows():
            lines.append(f"- {r.get('entity_label','')}：花费{_fmt_money(r.get('spend',0))}，点击{r.get('clicks',0):.0f}，订单0")
    else:
        lines.append("- 本周无明显浪费词。")

    if not recommendations_df.empty:
        exact_df = recommendations_df[recommendations_df["动作类型"] == "建议转Exact"]
        negate_df = recommendations_df[recommendations_df["动作类型"] == "建议否定"]
    else:
        exact_df = negate_df = pd.DataFrame()

    lines.append("\n## 8. 建议转Exact的词")
    lines += [f"- {r['建议对象']}：{r['判断原因']}" for _, r in exact_df.head(10).iterrows()] or ["- 暂无"]

    lines.append("\n## 9. 建议否定的词")
    lines += [f"- {r['建议对象']}：{r['判断原因']}" for _, r in negate_df.head(10).iterrows()] or ["- 暂无"]

    lines.append("\n## 10. 下周优化动作清单")
    action_counts = recommendations_df["动作类型"].value_counts() if not recommendations_df.empty else pd.Series(dtype=int)
    if not action_counts.empty:
        for action, cnt in action_counts.items():
            lines.append(f"- {action}：{cnt} 项")
    else:
        lines.append("- 本周无待办优化动作。")

    return "\n".join(lines)
