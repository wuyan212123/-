"""
周度对比逻辑，对应需求文档第 7 节。

术语约定（避免歧义，写明白防止误解）：
- "本周 vs 上周"：本周 = 用户当前查看的周期；上周 = 紧邻的前一个已上传周期。
- "本周 vs 近4周均值"：均值 = 本周之前最近 4 个周期的平均值（不含本周），作为基线对比。
- 标签规则里出现的"近4周"（如核心词、持续浪费词判断）：指包含本周在内、最近的 N 个周期
  （由设置项"核心词周期"决定，默认4），衡量的是近期趋势本身，不是"和谁比"。
"""
import numpy as np
import pandas as pd

from core.metrics import add_metrics, aggregate

BASE_COLS = ["impressions", "clicks", "spend", "sales", "orders"]


def sorted_periods(ad_rows_all: pd.DataFrame) -> list[tuple[str, str]]:
    if ad_rows_all.empty:
        return []
    periods = (
        ad_rows_all[["period_start", "period_end"]]
        .drop_duplicates()
        .sort_values("period_end")
    )
    return list(periods.itertuples(index=False, name=None))


def aggregate_by_period(ad_rows_all: pd.DataFrame, entity_cols: list[str]) -> pd.DataFrame:
    """按 entity_cols + 周期 聚合出每周指标（长表）。"""
    if ad_rows_all.empty:
        return pd.DataFrame(columns=entity_cols + ["period_start", "period_end"] + BASE_COLS)
    group_cols = entity_cols + ["period_start", "period_end"]
    return aggregate(ad_rows_all, group_cols)


def _period_index(periods: list[tuple[str, str]], period: tuple[str, str]) -> int:
    try:
        return periods.index(period)
    except ValueError:
        return -1


def previous_period(periods: list[tuple[str, str]], current: tuple[str, str]) -> tuple[str, str] | None:
    idx = _period_index(periods, current)
    if idx <= 0:
        return None
    return periods[idx - 1]


def baseline_avg_frame(
    long_df: pd.DataFrame,
    entity_cols: list[str],
    periods: list[tuple[str, str]],
    current: tuple[str, str],
    n_weeks: int = 4,
) -> pd.DataFrame:
    """本周之前最近 n_weeks 个周期的均值（不含本周），按 entity 聚合。"""
    idx = _period_index(periods, current)
    if idx <= 0:
        return pd.DataFrame(columns=entity_cols + [f"avg4_{c}" for c in BASE_COLS + ["ctr", "cpc", "cvr", "acos", "roas"]])
    window = periods[max(0, idx - n_weeks): idx]
    mask = long_df.apply(lambda r: (r["period_start"], r["period_end"]) in window, axis=1) if not long_df.empty else pd.Series([], dtype=bool)
    sub = long_df[mask] if not long_df.empty else long_df
    if sub.empty:
        return pd.DataFrame(columns=entity_cols + [f"avg4_{c}" for c in BASE_COLS + ["ctr", "cpc", "cvr", "acos", "roas"]])
    sums = sub.groupby(entity_cols, as_index=False)[BASE_COLS].sum()
    # 均值：基础量取每周平均，比率指标基于均值后的基础量重新计算（更稳健，避免小样本比率失真）
    for c in BASE_COLS:
        sums[c] = sums[c] / len(window)
    sums = add_metrics(sums)
    rename = {c: f"avg4_{c}" for c in BASE_COLS + ["ctr", "cpc", "cvr", "acos", "roas"]}
    return sums.rename(columns=rename)


def change_pct(current_val: float, base_val: float):
    """变化幅度，含新增/消失特殊情况处理（第7.2节）。返回 (pct_or_None, flag)"""
    if base_val == 0 and current_val > 0:
        return None, "new"
    if current_val == 0 and base_val > 0:
        return None, "disappeared"
    if base_val == 0 and current_val == 0:
        return None, "none"
    return (current_val - base_val) / base_val, "normal"


def build_comparison_table(
    current_df: pd.DataFrame,
    previous_df: pd.DataFrame,
    avg4_df: pd.DataFrame,
    entity_cols: list[str],
) -> pd.DataFrame:
    """合并本周/上周/近4周均值，输出对比表（第11.4节字段的基础数据）。"""
    cur = current_df.copy()
    prev = previous_df.copy().add_prefix("prev_") if not previous_df.empty else previous_df
    if not previous_df.empty:
        for c in entity_cols:
            prev = prev.rename(columns={f"prev_{c}": c})

    merged = cur.merge(prev, on=entity_cols, how="outer") if not previous_df.empty else cur.copy()
    if not avg4_df.empty:
        merged = merged.merge(avg4_df, on=entity_cols, how="left")

    # 缺失的数值列补 0（表示该周期无数据），除了 None 型变化标记另算
    for c in BASE_COLS + ["ctr", "cpc", "cvr", "acos", "roas"]:
        if c not in merged.columns:
            merged[c] = 0.0
        merged[c] = merged[c].fillna(0.0)
        pc = f"prev_{c}"
        if pc not in merged.columns:
            merged[pc] = 0.0
        merged[pc] = merged[pc].fillna(0.0)
        ac = f"avg4_{c}"
        if ac not in merged.columns:
            merged[ac] = np.nan

    changes = merged.apply(
        lambda r: change_pct(r["orders"], r["prev_orders"]), axis=1
    )
    merged["orders_change_flag"] = [c[1] for c in changes]

    for metric in ["spend", "sales", "clicks", "impressions", "acos", "ctr", "cvr", "cpc"]:
        pct_flags = merged.apply(lambda r, m=metric: change_pct(r[m], r[f"prev_{m}"]), axis=1)
        merged[f"{metric}_change_pct"] = [p[0] for p in pct_flags]
        merged[f"{metric}_change_flag"] = [p[1] for p in pct_flags]

    return merged


def trend_window_features(
    long_df: pd.DataFrame,
    entity_cols: list[str],
    periods: list[tuple[str, str]],
    current: tuple[str, str],
    window_weeks: int = 4,
) -> pd.DataFrame:
    """
    近 N 周（含本周）趋势特征，用于核心词/持续浪费词等规则判断：
    - weeks_present: 窗口内出现过数据的周数
    - weeks_with_orders: 窗口内有订单的周数
    - orders_sum / spend_sum / sales_sum: 窗口内累计
    - acos_window: 窗口内累计花费/累计销售额
    - consecutive_waste_weeks: 最近连续几周满足"点击>=15且订单=0"（用于持续浪费词）
    """
    idx = _period_index(periods, current)
    if idx < 0:
        return pd.DataFrame(columns=entity_cols)
    window = periods[max(0, idx - window_weeks + 1): idx + 1]
    if long_df.empty:
        return pd.DataFrame(columns=entity_cols)
    mask = long_df.apply(lambda r: (r["period_start"], r["period_end"]) in window, axis=1)
    sub = long_df[mask]
    if sub.empty:
        return pd.DataFrame(columns=entity_cols)

    def _agg(g: pd.DataFrame) -> pd.Series:
        weeks_present = g["period_start"].nunique()
        weeks_with_orders = (g.groupby(["period_start", "period_end"])["orders"].sum() > 0).sum()
        orders_sum = g["orders"].sum()
        spend_sum = g["spend"].sum()
        sales_sum = g["sales"].sum()
        acos_window = spend_sum / sales_sum if sales_sum > 0 else (np.inf if spend_sum > 0 else 0.0)

        ordered_window = [p for p in window if p in set(zip(g["period_start"], g["period_end"]))]
        by_period = g.groupby(["period_start", "period_end"])[["clicks", "orders"]].sum()
        consecutive = 0
        for p in reversed(window):
            if p not in by_period.index:
                break
            row = by_period.loc[p]
            if row["clicks"] >= 15 and row["orders"] == 0:
                consecutive += 1
            else:
                break

        return pd.Series(
            {
                "weeks_present": weeks_present,
                "weeks_with_orders": weeks_with_orders,
                "orders_sum_window": orders_sum,
                "spend_sum_window": spend_sum,
                "sales_sum_window": sales_sum,
                "acos_window": acos_window,
                "consecutive_waste_weeks": consecutive,
            }
        )

    result = sub.groupby(entity_cols).apply(_agg).reset_index()
    return result
