"""
Excel 导出，对应需求文档第 15 节。
"""
import io

import pandas as pd

DISPLAY_COLS = [
    "entity_label", "campaign_name", "ad_group_name", "match_type", "keyword_type",
    "impressions", "clicks", "spend", "sales", "orders", "ctr", "cpc", "cvr", "acos", "roas",
    "prev_impressions", "prev_clicks", "prev_spend", "prev_sales", "prev_orders",
    "avg4_spend", "avg4_orders", "avg4_acos",
    "tags_display",
]


def _select_cols(df: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in DISPLAY_COLS if c in df.columns]
    return df[cols].rename(columns={
        "entity_label": "搜索词/投放词", "campaign_name": "广告活动", "ad_group_name": "广告组",
        "match_type": "匹配类型", "keyword_type": "词类型",
        "impressions": "本周曝光", "clicks": "本周点击", "spend": "本周花费", "sales": "本周销售额",
        "orders": "本周订单", "ctr": "本周CTR", "cpc": "本周CPC", "cvr": "本周CVR", "acos": "本周ACOS",
        "roas": "本周ROAS",
        "prev_impressions": "上周曝光", "prev_clicks": "上周点击", "prev_spend": "上周花费",
        "prev_sales": "上周销售额", "prev_orders": "上周订单",
        "avg4_spend": "近4周均花费", "avg4_orders": "近4周均订单", "avg4_acos": "近4周均ACOS",
        "tags_display": "标签",
    })


def build_excel_export(
    overview_df: pd.DataFrame,
    tagged_df: pd.DataFrame,
    recommendations_df: pd.DataFrame,
) -> bytes:
    buf = io.BytesIO()
    tag_filters = {
        "新增词": tagged_df.get("tag_is_new", pd.Series(False, index=tagged_df.index)),
        "消失词": tagged_df.get("tag_is_disappeared", pd.Series(False, index=tagged_df.index)),
        "表现变好": tagged_df.get("tag_ctr_up", False) | tagged_df.get("tag_cvr_up", False)
        | tagged_df.get("tag_orders_up", False) | tagged_df.get("tag_acos_improved", False)
        | tagged_df.get("tag_scalable", False),
        "表现变差": tagged_df.get("tag_ctr_down", False) | tagged_df.get("tag_cvr_down", False)
        | tagged_df.get("tag_cpc_up", False) | tagged_df.get("tag_acos_worsened", False)
        | tagged_df.get("tag_spend_wasted", False) | tagged_df.get("tag_declining_converter", False),
        "核心词": tagged_df.get("tag_core", pd.Series(False, index=tagged_df.index)),
        "浪费词": tagged_df.get("tag_click_waste", False) | tagged_df.get("tag_spend_waste_cpa", False)
        | tagged_df.get("tag_persistent_waste", False) | tagged_df.get("tag_high_acos_loss", False),
    }

    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        if not overview_df.empty:
            overview_df.to_excel(writer, sheet_name="总览", index=False)
        else:
            pd.DataFrame({"提示": ["暂无总览数据"]}).to_excel(writer, sheet_name="总览", index=False)

        for sheet_name, mask in tag_filters.items():
            sub = tagged_df[mask] if not tagged_df.empty else tagged_df
            out = _select_cols(sub) if not sub.empty else pd.DataFrame({"提示": ["本周无该类词"]})
            out.to_excel(writer, sheet_name=sheet_name, index=False)

        if not recommendations_df.empty:
            exact_df = recommendations_df[recommendations_df["动作类型"] == "建议转Exact"]
            negate_df = recommendations_df[recommendations_df["动作类型"] == "建议否定"]
        else:
            exact_df = negate_df = pd.DataFrame()

        (exact_df if not exact_df.empty else pd.DataFrame({"提示": ["本周无转Exact建议"]})).to_excel(
            writer, sheet_name="转Exact建议", index=False
        )
        (negate_df if not negate_df.empty else pd.DataFrame({"提示": ["本周无否定建议"]})).to_excel(
            writer, sheet_name="否定建议", index=False
        )

        full = _select_cols(tagged_df) if not tagged_df.empty else pd.DataFrame({"提示": ["暂无数据"]})
        full.to_excel(writer, sheet_name="完整数据", index=False)

    return buf.getvalue()
