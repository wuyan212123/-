"""
优化建议规则，对应需求文档第 9 节。

每条建议输出：建议对象、当前数据、判断原因、建议动作、风险等级、优先级（第11.7节要求）。
第一版只输出建议，不自动修改广告。
"""
import numpy as np
import pandas as pd


def apply_new_product_mode(settings: dict) -> dict:
    """新品期模式：放宽 ACOS 和否定相关阈值（第10节 新品期模式 说明）。"""
    s = dict(settings)
    if s.get("new_product_mode"):
        s["target_acos"] = s["target_acos"] * 1.3
        s["click_no_order_threshold"] = int(s["click_no_order_threshold"] * 1.5)
        if s.get("target_cpa"):
            s["target_cpa"] = s["target_cpa"] * 1.5
    return s


def _priority(risk_level: str, spend: float) -> int:
    """1=最高优先级。风险越高、涉及花费越大，优先级越靠前。"""
    base = {"高": 0, "中": 1, "低": 2}.get(risk_level, 2)
    if spend >= 50:
        base -= 1
    return max(1, base + 1)


def _fmt_metrics(row) -> str:
    def g(k, fmt="{:.2f}"):
        v = row.get(k, 0)
        if v in (np.inf, -np.inf):
            return "∞"
        try:
            return fmt.format(v)
        except (ValueError, TypeError):
            return str(v)

    return (
        f"点击{g('clicks','{:.0f}')} 花费${g('spend')} 销售额${g('sales')} "
        f"订单{g('orders','{:.0f}')} ACOS{g('acos','{:.1%}')} CTR{g('ctr','{:.2%}')} CVR{g('cvr','{:.2%}')}"
    )


def keyword_recommendations(
    df: pd.DataFrame,
    settings: dict,
    entity_label_col: str,
    account_ctr: float,
    account_cvr: float,
    existing_exact_keywords: set[str] | None = None,
) -> pd.DataFrame:
    """
    针对搜索词/投放词粒度生成建议：转Exact、提竞价、降竞价、否定、检查Listing。
    df 需包含 tagging.compute_tags 输出的列。
    """
    existing_exact_keywords = existing_exact_keywords or set()
    settings = apply_new_product_mode(settings)
    target_acos = settings["target_acos"]
    min_clicks = settings["min_clicks_for_judgement"]

    records = []

    def add(row, action_type, reason, action, risk_level):
        records.append(
            {
                "动作类型": action_type,
                "建议对象": row.get(entity_label_col, ""),
                "广告活动": row.get("campaign_name", ""),
                "广告组": row.get("ad_group_name", ""),
                "匹配类型": row.get("match_type", ""),
                "当前数据": _fmt_metrics(row),
                "判断原因": reason,
                "建议动作": action,
                "风险等级": risk_level,
                "优先级": _priority(risk_level, row.get("spend", 0)),
            }
        )

    for _, row in df.iterrows():
        mt = str(row.get("match_type", "")).lower()
        orders_window = row.get("orders_sum_window", 0)
        acos_window = row.get("acos_window", 0)
        cur_acos = row.get("acos", 0)
        cur_orders = row.get("orders", 0)
        clicks = row.get("clicks", 0)
        cvr = row.get("cvr", 0)
        ctr = row.get("ctr", 0)
        norm_kw = row.get("keyword_norm", "")

        # 9.1 转 Exact
        if mt in ("auto", "broad", "phrase") and orders_window >= 2 and (cur_acos <= target_acos or acos_window <= target_acos):
            if norm_kw in existing_exact_keywords:
                add(
                    row, "建议转Exact",
                    f"来自{row.get('match_type')}广告，近期订单{orders_window:.0f}个，ACOS表现达标，但Exact广告中已存在该词",
                    "已存在Exact投放，建议检查其竞价和预算是否充足", "低",
                )
            else:
                note = "，建议保留原广告继续探索" if mt == "auto" else ""
                acos_note = f"本周ACOS{cur_acos:.1%}" if cur_acos <= target_acos else f"近期窗口ACOS{acos_window:.1%}"
                add(
                    row, "建议转Exact",
                    f"来自{row.get('match_type')}广告，近期订单{orders_window:.0f}个，{acos_note}达标",
                    f"建议将该词加入Exact精准广告{note}", "低",
                )

        # 9.2 提高竞价
        if (
            row.get("weeks_with_orders", 0) >= 2
            and cur_acos <= target_acos
            and cvr >= account_cvr
            and clicks < max(min_clicks * 4, 20)
            and cur_orders > 0
        ):
            premium = cvr / account_cvr if account_cvr > 0 else 1
            if premium >= 1.5:
                magnitude = "15%-20%（激进）"
            elif premium >= 1.2:
                magnitude = "10%-15%（正常）"
            else:
                magnitude = "5%-10%（保守）"
            add(
                row, "建议提高竞价",
                f"订单稳定、ACOS{cur_acos:.1%}低于目标、CVR{cvr:.1%}高于账户均值{account_cvr:.1%}，但曝光/点击不足",
                f"建议提高竞价 {magnitude}", "低",
            )

        # 9.3 降低竞价
        if cur_orders > 0 and cur_acos > target_acos and (row.get("cpc_change_pct") is not None and (row.get("cpc_change_pct") or 0) > 0 or cvr < account_cvr):
            stability = row.get("weeks_present", 0)
            if stability >= 3:
                magnitude = "15%-20%"
            elif stability >= 1:
                magnitude = "5%-15%"
            else:
                magnitude = "5%（数据不足，先小幅调整并观察）"
            add(
                row, "建议降低竞价",
                f"有订单但ACOS{cur_acos:.1%}高于目标{target_acos:.1%}，CPC上涨或CVR{cvr:.1%}低于账户均值",
                f"建议降低竞价 {magnitude}", "中",
            )

        # 9.4 否定关键词
        click_waste = clicks >= settings["click_no_order_threshold"] and cur_orders == 0
        spend_waste = settings.get("target_cpa") and row.get("spend", 0) >= settings["target_cpa"] and cur_orders == 0
        if click_waste or spend_waste:
            kw_type = row.get("keyword_type", "")
            if kw_type == "brand":
                add(
                    row, "建议否定",
                    f"点击{clicks:.0f}次无订单，但识别为品牌词/竞品词",
                    "品牌词/竞品词请人工确认相关性，不要直接否定", "中",
                )
            elif kw_type == "asin":
                add(
                    row, "建议否定",
                    f"ASIN投放点击{clicks:.0f}次无订单",
                    "建议否定该ASIN或暂停该商品投放", "中",
                )
            else:
                add(
                    row, "建议否定",
                    f"点击{clicks:.0f}次无订单（阈值{settings['click_no_order_threshold']}）" + (
                        "，新品期已放宽阈值" if settings.get("new_product_mode") else ""
                    ),
                    "建议否定精准(Negative Exact)；如为泛词整体不相关，改用词组否定(Negative Phrase)", "中",
                )

        # 9.6 Listing 检查
        if ctr > 0 and ctr >= account_ctr and clicks >= min_clicks and cvr < account_cvr:
            add(
                row, "建议检查Listing",
                f"CTR{ctr:.2%}高于账户均值{account_ctr:.2%}，点击充足({clicks:.0f})，但CVR{cvr:.2%}低于账户均值{account_cvr:.2%}",
                "检查价格、Coupon、主图、评论数与评分、五点描述/A+、竞品价格变化", "中",
            )

    return pd.DataFrame(records)


def campaign_budget_recommendations(campaign_trend_df: pd.DataFrame, settings: dict) -> pd.DataFrame:
    """
    9.5 加预算建议：无法获取预算使用率时，用花费趋势替代（近几周花费持续处于较高水平）。
    campaign_trend_df: 按 campaign_name + period 聚合的历史指标（长表，见 compare.aggregate_by_period）。
    """
    settings = apply_new_product_mode(settings)
    target_acos = settings["target_acos"]
    records = []
    if campaign_trend_df.empty:
        return pd.DataFrame(records)

    for campaign, g in campaign_trend_df.groupby("campaign_name"):
        g = g.sort_values("period_end")
        if len(g) < 2:
            continue
        recent = g.tail(3)
        spend_trend_up = recent["spend"].is_monotonic_increasing and len(recent) >= 2
        latest = g.iloc[-1]
        if spend_trend_up and latest["acos"] <= target_acos and latest["orders"] > 0:
            records.append(
                {
                    "动作类型": "建议检查预算",
                    "建议对象": campaign,
                    "广告活动": campaign,
                    "广告组": "",
                    "匹配类型": "",
                    "当前数据": f"最近{len(recent)}周花费持续上升，本周花费${latest['spend']:.2f} ACOS{latest['acos']:.1%}",
                    "判断原因": "花费趋势持续走高且ACOS达标、订单稳定，可能已达预算上限（暂无预算使用率数据，以花费趋势替代判断）",
                    "建议动作": "检查Campaign每日预算是否接近上限，如是则适当提高预算",
                    "风险等级": "低",
                    "优先级": _priority("低", latest["spend"]),
                }
            )
    return pd.DataFrame(records)
