"""
数据清洗：读取上传文件 -> 字段映射 -> 数值清洗 -> 关键词文本清洗 -> 去重合并。
对应需求文档第 6 节。
"""
import io
import re

import numpy as np
import pandas as pd

from core.field_mapping import build_rename_map, missing_required_fields

ASIN_PATTERN = re.compile(r"^b0[a-z0-9]{8}$", re.IGNORECASE)

NUMERIC_STD_FIELDS = ["impressions", "clicks", "spend", "sales", "orders"]

ENTITY_TEXT_FIELDS = [
    "portfolio_name",
    "campaign_name",
    "ad_group_name",
    "match_type",
    "targeting",
    "search_term",
    "customer_search_term",
    "advertised_asin",
    "sku",
]


class ReportParseResult:
    def __init__(self):
        self.df: pd.DataFrame | None = None
        self.raw_row_count = 0
        self.final_row_count = 0
        self.duplicate_count = 0
        self.unmapped_columns: list[str] = []
        self.missing_fields: list[str] = []
        self.campaign_count = 0
        self.search_term_count = 0
        self.targeting_count = 0
        self.errors: list[str] = []


def read_report_file(uploaded_file, filename: str) -> pd.DataFrame:
    """读取 .xlsx 或 .csv 文件为 DataFrame（原始列名）。"""
    name = filename.lower()
    data = uploaded_file.read() if hasattr(uploaded_file, "read") else uploaded_file
    if name.endswith(".csv"):
        # 兼容常见编码
        for enc in ("utf-8-sig", "utf-8", "gbk"):
            try:
                return pd.read_csv(io.BytesIO(data), encoding=enc)
            except (UnicodeDecodeError, UnicodeError):
                continue
        return pd.read_csv(io.BytesIO(data), encoding="latin1")
    elif name.endswith(".xlsx") or name.endswith(".xls"):
        return pd.read_excel(io.BytesIO(data))
    else:
        raise ValueError("只支持 .xlsx 或 .csv 文件")


def _clean_numeric_series(s: pd.Series) -> pd.Series:
    if s.dtype != object:
        return pd.to_numeric(s, errors="coerce").fillna(0.0)
    cleaned = (
        s.astype(str)
        .str.replace(r"[$,¥￥,]", "", regex=True)
        .str.replace("%", "", regex=False)
        .str.strip()
    )
    cleaned = cleaned.replace({"": "0", "nan": "0", "-": "0", "None": "0"})
    return pd.to_numeric(cleaned, errors="coerce").fillna(0.0)


def normalize_keyword_text(text) -> str:
    if text is None or (isinstance(text, float) and np.isnan(text)):
        return ""
    t = str(text).strip().lower()
    t = re.sub(r"\s+", " ", t)
    return t


def classify_keyword_type(norm_text: str, brand_words: set[str]) -> str:
    if not norm_text:
        return ""
    if ASIN_PATTERN.match(norm_text.replace(" ", "")):
        return "asin"
    for bw in brand_words:
        bw = bw.strip().lower()
        if bw and bw in norm_text:
            return "brand"
    word_count = len(norm_text.split())
    return "longtail" if word_count >= 4 else "generic"


def parse_and_clean(
    uploaded_file,
    filename: str,
    report_type: str,
    brand_words: set[str] | None = None,
) -> ReportParseResult:
    """
    完整清洗流程，返回 ReportParseResult，其中 df 为标准化后的 DataFrame。
    """
    result = ReportParseResult()
    brand_words = brand_words or set()
    try:
        raw_df = read_report_file(uploaded_file, filename)
    except Exception as e:  # noqa: BLE001
        result.errors.append(f"文件解析失败: {e}")
        return result

    result.raw_row_count = len(raw_df)
    rename_map, unmapped = build_rename_map(list(raw_df.columns))
    result.unmapped_columns = unmapped

    df = raw_df.rename(columns=rename_map)
    # 若同一标准字段被多个原始列映射到，保留第一次出现的列
    df = df.loc[:, ~df.columns.duplicated()]

    mapped_fields = set(rename_map.values())
    result.missing_fields = missing_required_fields(mapped_fields, report_type)

    # 补齐缺失的标准字段，避免后续 KeyError
    for f in ENTITY_TEXT_FIELDS + NUMERIC_STD_FIELDS:
        if f not in df.columns:
            df[f] = "" if f in ENTITY_TEXT_FIELDS else 0.0

    for f in NUMERIC_STD_FIELDS:
        df[f] = _clean_numeric_series(df[f])

    for f in ENTITY_TEXT_FIELDS:
        df[f] = df[f].fillna("").astype(str).str.strip()

    # search_term report 里 targeting 缺失时用 customer_search_term 兜底展示
    if report_type == "search_term":
        entity_field = "customer_search_term"
    else:
        entity_field = "targeting"

    df["keyword_norm"] = df[entity_field].apply(normalize_keyword_text)
    df["keyword_type"] = df["keyword_norm"].apply(lambda t: classify_keyword_type(t, brand_words))

    # 去重合并：同一 campaign/ad_group/match_type/entity 组合的重复行，数值求和
    group_cols = ["campaign_name", "ad_group_name", "match_type", "targeting"]
    if report_type == "search_term":
        group_cols.append("customer_search_term")

    before = len(df)
    agg_map = {f: "sum" for f in NUMERIC_STD_FIELDS}
    other_cols = [c for c in df.columns if c not in group_cols and c not in agg_map]
    for c in other_cols:
        agg_map[c] = "first"
    df = df.groupby(group_cols, dropna=False, as_index=False).agg(agg_map)
    result.duplicate_count = before - len(df)

    result.df = df
    result.final_row_count = len(df)
    result.campaign_count = df["campaign_name"].nunique()
    result.search_term_count = (
        df["customer_search_term"].nunique() if "customer_search_term" in df.columns else 0
    )
    result.targeting_count = df["targeting"].nunique() if "targeting" in df.columns else 0
    return result
