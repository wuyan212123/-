import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
import streamlit as st

from core import db
from core.cleaning import parse_and_clean
from core.context import load_settings_cached
from core.styling import inject_css

st.set_page_config(page_title="SP广告周度分析助手", page_icon="📊", layout="wide")
db.init_db()
inject_css()

st.title("📊 SP广告周度分析助手")
st.caption("上传亚马逊 SP 广告报表，自动按周对比、打标签、给建议。第一版只分析 Sponsored Products。")

settings = load_settings_cached()

st.markdown("### 1. 选择数据范围与周期")
col1, col2, col3 = st.columns(3)
with col1:
    store = st.text_input("店铺名称", placeholder="例如：MyBrand-US")
with col2:
    marketplace = st.text_input("站点", value="US")
with col3:
    product = st.text_input("产品 / SKU / ASIN", placeholder="例如：B0XXXXXXXX 或 全店")

col4, col5, col6 = st.columns(3)
with col4:
    period_start = st.date_input("数据周期开始日期")
with col5:
    period_end = st.date_input("数据周期结束日期")
with col6:
    report_type = st.selectbox(
        "报表类型",
        options=["search_term", "targeting", "campaign"],
        format_func=lambda x: {
            "search_term": "Search Term Report（搜索词报表）",
            "targeting": "Targeting Report（投放报表）",
            "campaign": "Campaign Report（广告活动报表，暂不参与打标签，仅用于花费趋势）",
        }[x],
    )

st.markdown("### 2. 上传文件")
uploaded_file = st.file_uploader("支持 .xlsx / .csv", type=["xlsx", "xls", "csv"])

can_submit = bool(store and marketplace and product and uploaded_file and period_start <= period_end)
if uploaded_file and period_start > period_end:
    st.error("开始日期不能晚于结束日期。")

if st.button("上传并解析", type="primary", disabled=not can_submit):
    if report_type == "campaign":
        st.warning("Campaign Report 第一版仅作花费趋势参考，暂未接入独立解析，请优先上传 Search Term / Targeting Report。")
    else:
        brand_words = set(settings.get("brand_words", []))
        result = parse_and_clean(uploaded_file, uploaded_file.name, report_type, brand_words)
        if result.errors:
            for e in result.errors:
                st.error(e)
        else:
            meta = {
                "store": store.strip(),
                "marketplace": marketplace.strip(),
                "product": product.strip(),
                "report_type": report_type,
                "period_start": str(period_start),
                "period_end": str(period_end),
                "filename": uploaded_file.name,
                "raw_row_count": result.raw_row_count,
                "final_row_count": result.final_row_count,
                "duplicate_count": result.duplicate_count,
                "campaign_count": result.campaign_count,
                "search_term_count": result.search_term_count,
                "targeting_count": result.targeting_count,
                "unmapped_columns": result.unmapped_columns,
                "missing_fields": result.missing_fields,
            }
            db.save_upload(meta, result.df)
            st.success(f"上传成功！共导入 {result.final_row_count} 行数据。")

            m1, m2, m3, m4 = st.columns(4)
            m1.metric("成功导入行数", result.final_row_count)
            m2.metric("识别到 Campaign", result.campaign_count)
            if report_type == "search_term":
                m3.metric("识别到 Search Term", result.search_term_count)
            else:
                m3.metric("识别到 Targeting", result.targeting_count)
            m4.metric("合并重复行数", result.duplicate_count)

            if result.missing_fields:
                st.error(f"缺少必须字段，可能影响分析准确性：{', '.join(result.missing_fields)}")
            if result.unmapped_columns:
                st.warning(f"以下原始列未能自动识别映射（不影响已识别字段）：{', '.join(result.unmapped_columns)}")
            st.session_state["scope_label"] = f"{meta['store']} / {meta['marketplace']} / {meta['product']}"

st.divider()
st.markdown("### 已上传记录")
uploads_df = db.list_uploads()
if uploads_df.empty:
    st.info("暂无上传记录。")
else:
    show_cols = [
        "uploaded_at", "store", "marketplace", "product", "report_type",
        "period_start", "period_end", "final_row_count", "campaign_count",
        "search_term_count", "targeting_count", "duplicate_count", "filename",
    ]
    st.dataframe(uploads_df[show_cols], use_container_width=True, hide_index=True)

st.divider()
st.page_link("pages/1_总览看板.py", label="➡️ 前往总览看板", icon="📊")
