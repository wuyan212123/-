import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from core import db
from core.context import load_settings_cached
from core.styling import inject_css

st.set_page_config(page_title="设置 - SP广告周度分析助手", page_icon="⚙️", layout="wide")
db.init_db()
inject_css()

st.title("⚙️ 阈值与参数设置")
st.caption("所有判断阈值均可自定义，不写死在代码里（第10节要求）。")

settings = load_settings_cached()

c1, c2 = st.columns(2)
with c1:
    target_acos = st.number_input("目标ACOS", min_value=0.0, max_value=2.0, value=float(settings["target_acos"]), step=0.01, format="%.2f")
    high_acos_multiplier = st.number_input("高ACOS倍数", min_value=1.0, max_value=5.0, value=float(settings["high_acos_multiplier"]), step=0.1)
    click_no_order_threshold = st.number_input("点击无单阈值", min_value=1, max_value=200, value=int(settings["click_no_order_threshold"]))
    min_clicks_for_judgement = st.number_input("最低判断点击数", min_value=1, max_value=100, value=int(settings["min_clicks_for_judgement"]))
    target_cpa_enabled = st.checkbox("设置目标CPA", value=settings.get("target_cpa") is not None)
    target_cpa = None
    if target_cpa_enabled:
        target_cpa = st.number_input("目标CPA ($)", min_value=0.0, value=float(settings.get("target_cpa") or 20.0), step=1.0)

with c2:
    ctr_improve_threshold = st.number_input("CTR提升阈值", min_value=0.0, max_value=5.0, value=float(settings["ctr_improve_threshold"]), step=0.05, format="%.2f")
    cvr_improve_threshold = st.number_input("CVR提升阈值", min_value=0.0, max_value=5.0, value=float(settings["cvr_improve_threshold"]), step=0.05, format="%.2f")
    acos_worsen_threshold = st.number_input("ACOS恶化阈值", min_value=0.0, max_value=5.0, value=float(settings["acos_worsen_threshold"]), step=0.05, format="%.2f")
    cpc_rise_threshold = st.number_input("CPC上涨阈值", min_value=0.0, max_value=5.0, value=float(settings["cpc_rise_threshold"]), step=0.05, format="%.2f")
    core_word_weeks = st.number_input("核心词周期（周）", min_value=2, max_value=12, value=int(settings["core_word_weeks"]))
    new_product_mode = st.toggle("新品期模式（放宽ACOS与否定阈值）", value=bool(settings.get("new_product_mode")))

st.markdown("### 品牌词 / 竞品词词表")
st.caption("用于识别品牌词，避免被自动归类为可直接否定的浪费词。每行一个词。")
brand_words_text = st.text_area(
    "品牌词列表", value="\n".join(settings.get("brand_words", [])), height=120
)

if st.button("💾 保存设置", type="primary"):
    new_settings = {
        "target_acos": target_acos,
        "high_acos_multiplier": high_acos_multiplier,
        "click_no_order_threshold": click_no_order_threshold,
        "min_clicks_for_judgement": min_clicks_for_judgement,
        "target_cpa": target_cpa,
        "ctr_improve_threshold": ctr_improve_threshold,
        "cvr_improve_threshold": cvr_improve_threshold,
        "acos_worsen_threshold": acos_worsen_threshold,
        "cpc_rise_threshold": cpc_rise_threshold,
        "core_word_weeks": core_word_weeks,
        "new_product_mode": new_product_mode,
        "brand_words": [w.strip() for w in brand_words_text.splitlines() if w.strip()],
    }
    db.save_settings(new_settings)
    st.session_state["settings"] = new_settings
    st.success("设置已保存，将在下次分析时生效。")
