import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from core import db, pipeline
from core.context import load_settings_cached, scope_selector
from core.styling import COLOR_NEUTRAL, direction_color, inject_css, kpi_card

st.set_page_config(page_title="总览看板 - SP广告周度分析助手", page_icon="📊", layout="wide")
db.init_db()
inject_css()

st.title("📊 总览看板")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope
settings = load_settings_cached()

overview = pipeline.compute_overview(store, marketplace, product, settings)
if not overview:
    st.info("该范围下还没有可用于总览的数据，请先上传 Targeting Report 或 Search Term Report。")
    st.stop()

st.caption(
    f"数据来源：{'Targeting Report' if overview['report_source']=='targeting' else 'Search Term Report'}　"
    f"本周：{overview['current_period'][0]} ~ {overview['current_period'][1]}"
    + (f"　上周：{overview['previous_period'][0]} ~ {overview['previous_period'][1]}" if overview.get("previous_period") else "")
)

metrics_spec = [
    ("曝光", "impressions", "{:,.0f}", "up"),
    ("点击", "clicks", "{:,.0f}", "up"),
    ("花费", "spend", "${:,.2f}", "down"),
    ("销售额", "sales", "${:,.2f}", "up"),
    ("订单", "orders", "{:,.0f}", "up"),
    ("CTR", "ctr", "{:.2%}", "up"),
    ("CPC", "cpc", "${:.2f}", "down"),
    ("CVR", "cvr", "{:.2%}", "up"),
    ("ACOS", "acos", "{:.1%}", "down"),
    ("ROAS", "roas", "{:.2f}", "up"),
]

cols = st.columns(5)
for i, (label, key, fmt, good_when) in enumerate(metrics_spec):
    cur = overview.get(key, 0)
    prev = overview.get(f"prev_{key}", 0)
    pct = None if prev == 0 else (cur - prev) / prev
    color = direction_color(pct, good_when)
    pct_str = f"{pct:+.1%}" if pct is not None else ("新增" if cur > 0 else "—")
    sub = f'<span style="color:{color};font-weight:600;">{pct_str}</span> 环比上周　上周 {fmt.format(prev)}'
    with cols[i % 5]:
        kpi_card(label, fmt.format(cur) if cur not in (float("inf"),) else "∞", sub)

st.markdown("")
avg4_acos = overview.get("avg4_acos")
if avg4_acos is not None:
    st.markdown("### 本周 vs 近4周均值")
    a1, a2, a3 = st.columns(3)
    with a1:
        kpi_card("近4周均ACOS", f"{avg4_acos:.1%}", f"本周 {overview.get('acos',0):.1%}")
    with a2:
        kpi_card("近4周均花费", f"${overview.get('avg4_spend',0):,.2f}", f"本周 ${overview.get('spend',0):,.2f}")
    with a3:
        kpi_card("近4周均订单", f"{overview.get('avg4_orders',0):,.1f}", f"本周 {overview.get('orders',0):,.0f}")
else:
    st.info("历史周期不足4周，暂无法计算近4周均值基线（会随着上传更多周数据自动补全）。")
