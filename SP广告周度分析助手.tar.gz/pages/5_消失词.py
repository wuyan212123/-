import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from core import db, pipeline
from core.context import load_settings_cached, report_type_selector, scope_selector
from core.styling import inject_css

st.set_page_config(page_title="消失词 - SP广告周度分析助手", page_icon="📉", layout="wide")
db.init_db()
inject_css()

st.title("📉 消失词")
st.caption("上周或历史有效表现，本周无曝光/点击/订单的词，需要排查原因。")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope
report_type = report_type_selector()
settings = load_settings_cached()

result = pipeline.run_entity_analysis(store, marketplace, product, report_type, settings)
if not result.available:
    st.info("暂无数据。")
    st.stop()

df = result.tagged_df
disappeared_df = df[df["tag_is_disappeared"]].copy()
disappeared_df = disappeared_df.sort_values(
    by=["tag_disappeared_high_value", "tag_disappeared_key", "orders_sum_window"],
    ascending=[False, False, False],
)

st.markdown(f"本周消失词共 **{len(disappeared_df)}** 个")

cols_show = [
    "entity_label", "campaign_name", "ad_group_name", "match_type",
    "prev_impressions", "prev_clicks", "prev_orders", "prev_acos",
    "orders_sum_window", "acos_window", "tags_display",
]
rename = {
    "entity_label": "搜索词/投放词", "campaign_name": "广告活动", "ad_group_name": "广告组", "match_type": "匹配类型",
    "prev_impressions": "上周曝光", "prev_clicks": "上周点击", "prev_orders": "上周订单", "prev_acos": "上周ACOS",
    "orders_sum_window": "近4周累计订单", "acos_window": "近4周ACOS", "tags_display": "标签",
}

if disappeared_df.empty:
    st.success("本周没有消失词。")
else:
    st.dataframe(
        disappeared_df[cols_show].rename(columns=rename).style.format(
            {"上周ACOS": "{:.1%}", "近4周ACOS": "{:.1%}"}, na_rep="-"
        ),
        use_container_width=True,
        height=500,
    )

    st.markdown("### 排查建议")
    st.markdown(
        "- 是否预算不足（花费未达上限却停投）；\n"
        "- 是否竞价被下调；\n"
        "- 是否广告活动/广告组被暂停；\n"
        "- 是否该关键词被否定；\n"
        "- Listing 相关性是否下降；\n"
        "- 产品是否断货或失去购物车（Buy Box）；\n"
        "- 排名或竞争环境是否变化。"
    )
