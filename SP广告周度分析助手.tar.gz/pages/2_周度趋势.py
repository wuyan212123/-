import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from core import db, pipeline
from core.context import scope_selector
from core.styling import inject_css

st.set_page_config(page_title="周度趋势 - SP广告周度分析助手", page_icon="📈", layout="wide")
db.init_db()
inject_css()

st.title("📈 周度趋势")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope

trend_df = pipeline.trend_series(store, marketplace, product)
if trend_df.empty:
    st.info("暂无数据。")
    st.stop()

n_weeks = st.slider("展示最近 N 周", min_value=2, max_value=max(2, len(trend_df)), value=min(8, len(trend_df)))
trend_df = trend_df.tail(n_weeks)

st.caption(f"数据来源：{'Targeting Report' if trend_df['report_source'].iloc[0]=='targeting' else 'Search Term Report'}")

fig1 = make_subplots(specs=[[{"secondary_y": True}]])
fig1.add_trace(go.Scatter(x=trend_df["period_label"], y=trend_df["spend"], name="花费", line=dict(color="#dc2626")))
fig1.add_trace(go.Scatter(x=trend_df["period_label"], y=trend_df["sales"], name="销售额", line=dict(color="#16a34a")))
fig1.update_layout(title="花费 / 销售额趋势", height=350, legend=dict(orientation="h"))
st.plotly_chart(fig1, use_container_width=True)

c1, c2 = st.columns(2)
with c1:
    fig2 = go.Figure(go.Scatter(x=trend_df["period_label"], y=trend_df["acos"], line=dict(color="#f59e0b")))
    fig2.update_layout(title="ACOS 趋势", height=300, yaxis_tickformat=".0%")
    st.plotly_chart(fig2, use_container_width=True)
with c2:
    fig3 = go.Figure(go.Bar(x=trend_df["period_label"], y=trend_df["orders"], marker_color="#2563eb"))
    fig3.update_layout(title="订单趋势", height=300)
    st.plotly_chart(fig3, use_container_width=True)

c3, c4 = st.columns(2)
with c3:
    fig4 = make_subplots(specs=[[{"secondary_y": True}]])
    fig4.add_trace(go.Scatter(x=trend_df["period_label"], y=trend_df["ctr"], name="CTR"), secondary_y=False)
    fig4.add_trace(go.Scatter(x=trend_df["period_label"], y=trend_df["cvr"], name="CVR"), secondary_y=True)
    fig4.update_layout(title="CTR / CVR 趋势", height=300, legend=dict(orientation="h"))
    st.plotly_chart(fig4, use_container_width=True)
with c4:
    fig5 = go.Figure(go.Scatter(x=trend_df["period_label"], y=trend_df["cpc"], line=dict(color="#7c3aed")))
    fig5.update_layout(title="CPC 趋势", height=300)
    st.plotly_chart(fig5, use_container_width=True)
