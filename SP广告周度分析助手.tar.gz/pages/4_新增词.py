import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from core import db, pipeline
from core.context import load_settings_cached, report_type_selector, scope_selector
from core.styling import inject_css

st.set_page_config(page_title="新增词 - SP广告周度分析助手", page_icon="🆕", layout="wide")
db.init_db()
inject_css()

st.title("🆕 新增词")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope
report_type = report_type_selector()
settings = load_settings_cached()

result = pipeline.run_entity_analysis(store, marketplace, product, report_type, settings)
if not result.available:
    st.info("暂无数据。")
    st.stop()

df = result.tagged_df
new_df = df[df["tag_is_new"]].copy()
new_df["新增浪费"] = (new_df["clicks"] >= settings["click_no_order_threshold"]) & (new_df["orders"] == 0)

st.markdown(f"本周新增词共 **{len(new_df)}** 个（上周及历史均无数据）")

cols_show = ["entity_label", "campaign_name", "ad_group_name", "match_type", "impressions", "clicks", "ctr", "cvr", "orders", "sales", "acos"]
rename = {"entity_label": "搜索词/投放词", "campaign_name": "广告活动", "ad_group_name": "广告组", "match_type": "匹配类型",
          "impressions": "曝光", "clicks": "点击", "ctr": "CTR", "cvr": "CVR", "orders": "订单", "sales": "销售额", "acos": "ACOS"}

tabs = st.tabs(["新增有曝光", "新增有点击", "新增有订单", "新增高潜力", "新增浪费"])
groups = [
    new_df[new_df["tag_new_impression"]],
    new_df[new_df["tag_new_click"]],
    new_df[new_df["tag_new_order"]],
    new_df[new_df["tag_new_high_potential"]],
    new_df[new_df["新增浪费"]],
]
for tab, g in zip(tabs, groups):
    with tab:
        st.markdown(f"共 {len(g)} 个")
        if g.empty:
            st.caption("暂无")
        else:
            st.dataframe(
                g[cols_show].rename(columns=rename).style.format(
                    {"CTR": "{:.2%}", "CVR": "{:.2%}", "ACOS": "{:.1%}", "销售额": "${:.2f}"}, na_rep="-"
                ),
                use_container_width=True,
            )
