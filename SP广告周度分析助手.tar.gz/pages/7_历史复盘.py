import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import json

import streamlit as st

from core import db
from core.context import scope_selector
from core.styling import inject_css

st.set_page_config(page_title="历史复盘 - SP广告周度分析助手", page_icon="🗂", layout="wide")
db.init_db()
inject_css()

st.title("🗂 历史复盘")
st.caption("记录每次在「优化建议」页面保存的周度分析快照。")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope

runs = db.list_analysis_runs(store, marketplace, product)
if runs.empty:
    st.info("暂无历史快照。请到「优化建议」页面生成周报后点击「保存本次分析快照」。")
    st.stop()

for _, run in runs.iterrows():
    summary = json.loads(run["summary_json"])
    with st.expander(f"{run['period_start']} ~ {run['period_end']}　保存于 {run['created_at']}", expanded=False):
        c1, c2, c3 = st.columns(3)
        ov = summary.get("overview", {})
        c1.metric("花费", f"${ov.get('spend', 0):,.2f}")
        c2.metric("销售额", f"${ov.get('sales', 0):,.2f}")
        c3.metric("ACOS", f"{ov.get('acos', 0):.1%}")

        st.markdown("**标签数量统计**")
        tag_counts = summary.get("tag_counts", {})
        st.json({k: v for k, v in tag_counts.items() if v}, expanded=False)

        st.markdown("**优化建议数量统计**")
        st.json(summary.get("recommendation_counts", {}), expanded=False)

        if summary.get("weekly_report"):
            st.markdown("**文字周报**")
            st.markdown(summary["weekly_report"])
