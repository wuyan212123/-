import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import streamlit as st

from core import db, pipeline
from core.context import load_settings_cached, report_type_selector, scope_selector
from core.styling import inject_css
from core.weekly_report import generate_weekly_report

st.set_page_config(page_title="优化建议 - SP广告周度分析助手", page_icon="✅", layout="wide")
db.init_db()
inject_css()

st.title("✅ 优化建议")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope
report_type = report_type_selector()
settings = load_settings_cached()

result = pipeline.run_entity_analysis(store, marketplace, product, report_type, settings)
if not result.available:
    st.info("暂无数据。")
    st.stop()

recs = result.recommendations_df.copy()
if recs.empty:
    st.success("本周暂无需要处理的优化建议。")
    st.stop()

action_types = recs["动作类型"].unique().tolist()
tab_labels = action_types
tabs = st.tabs(tab_labels)
for tab, action in zip(tabs, action_types):
    with tab:
        sub = recs[recs["动作类型"] == action].sort_values("优先级")
        st.markdown(f"共 {len(sub)} 条")
        st.dataframe(
            sub[["建议对象", "广告活动", "广告组", "匹配类型", "当前数据", "判断原因", "建议动作", "风险等级", "优先级"]],
            use_container_width=True,
            height=450,
        )

st.divider()
if st.button("📝 生成本周文字周报"):
    st.session_state["weekly_report_text"] = generate_weekly_report(
        pipeline.compute_overview(store, marketplace, product, settings), result.tagged_df, recs
    )

if st.session_state.get("weekly_report_text"):
    st.markdown(st.session_state["weekly_report_text"])
    if st.button("💾 保存本次分析快照到历史复盘"):
        overview = pipeline.compute_overview(store, marketplace, product, settings)
        tag_counts = {
            t: int(result.tagged_df[t].sum())
            for t in result.tagged_df.columns
            if t.startswith("tag_") and result.tagged_df[t].dtype == bool
        }
        summary = {
            "overview": {k: v for k, v in overview.items() if k not in ("periods",)},
            "tag_counts": tag_counts,
            "recommendation_counts": recs["动作类型"].value_counts().to_dict(),
            "report_type": report_type,
            "weekly_report": st.session_state["weekly_report_text"],
        }
        db.save_analysis_run(store, marketplace, product, result.current_period[0], result.current_period[1], summary)
        st.success("已保存到历史复盘页面。")
