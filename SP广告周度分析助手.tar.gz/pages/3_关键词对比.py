import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import streamlit as st

from core import db, pipeline
from core.context import load_settings_cached, report_type_selector, scope_selector
from core.export_excel import build_excel_export
from core.styling import inject_css

st.set_page_config(page_title="关键词对比 - SP广告周度分析助手", page_icon="🔍", layout="wide")
db.init_db()
inject_css()

st.title("🔍 关键词 / 搜索词对比")
st.caption("本程序最核心页面：本周 vs 上周 vs 近4周均值，逐词对比 + 标签 + 建议动作。")

scope = scope_selector()
if not scope:
    st.stop()
store, marketplace, product = scope
report_type = report_type_selector()
settings = load_settings_cached()

result = pipeline.run_entity_analysis(store, marketplace, product, report_type, settings)
if not result.available:
    st.info("该报表类型暂无数据，请先上传。")
    st.stop()

df = result.tagged_df.copy()
recs = result.recommendations_df.copy()

action_by_entity = (
    recs.groupby("建议对象")["动作类型"].apply(lambda s: "、".join(sorted(set(s)))).to_dict()
    if not recs.empty else {}
)
df["建议动作"] = df["entity_label"].map(action_by_entity).fillna("")

st.caption(
    f"本周：{result.current_period[0]} ~ {result.current_period[1]}"
    + (f"　上周：{result.previous_period[0]} ~ {result.previous_period[1]}" if result.previous_period else "　（暂无上周数据）")
    + f"　账户本周平均CTR {result.account_ctr:.2%}　账户本周平均CVR {result.account_cvr:.2%}"
)

with st.expander("筛选条件", expanded=True):
    f1, f2, f3, f4 = st.columns(4)
    campaigns = f1.multiselect("广告活动", sorted(df["campaign_name"].dropna().unique()))
    ad_groups = f2.multiselect("广告组", sorted(df["ad_group_name"].dropna().unique()))
    match_types = f3.multiselect("匹配类型", sorted(df["match_type"].dropna().unique()))
    kw_types = f4.multiselect("搜索词类型", sorted(df["keyword_type"].dropna().unique()))

    all_tags = sorted({t for ts in df["tags"] for t in ts})
    f5, f6, f7 = st.columns(3)
    tag_filter = f5.multiselect("标签", all_tags)
    has_orders = f6.selectbox("是否有订单", ["不限", "有订单", "无订单"])
    acos_pct_range = f7.slider("本周ACOS范围", 0, 300, (0, 300), step=5, format="%d%%")
    acos_range = (acos_pct_range[0] / 100, acos_pct_range[1] / 100)

    f8, _ = st.columns(2)
    click_range = f8.slider("本周点击范围", 0, int(max(50, df["clicks"].max())), (0, int(max(50, df["clicks"].max()))))

filtered = df.copy()
if campaigns:
    filtered = filtered[filtered["campaign_name"].isin(campaigns)]
if ad_groups:
    filtered = filtered[filtered["ad_group_name"].isin(ad_groups)]
if match_types:
    filtered = filtered[filtered["match_type"].isin(match_types)]
if kw_types:
    filtered = filtered[filtered["keyword_type"].isin(kw_types)]
if tag_filter:
    filtered = filtered[filtered["tags"].apply(lambda ts: any(t in ts for t in tag_filter))]
if has_orders == "有订单":
    filtered = filtered[filtered["orders"] > 0]
elif has_orders == "无订单":
    filtered = filtered[filtered["orders"] == 0]
acos_upper_unbounded = acos_pct_range[1] >= 300
acos_mask = filtered["acos"] >= acos_range[0]
if not acos_upper_unbounded:
    acos_mask &= filtered["acos"] <= acos_range[1]
filtered = filtered[acos_mask]
filtered = filtered[(filtered["clicks"] >= click_range[0]) & (filtered["clicks"] <= click_range[1])]

st.markdown(f"**共 {len(filtered)} 条记录**（全部 {len(df)} 条）")

display_cols = {
    "entity_label": "搜索词/投放词",
    "tags_display": "标签",
    "campaign_name": "广告活动",
    "ad_group_name": "广告组",
    "match_type": "匹配类型",
    "impressions": "本周曝光",
    "clicks": "本周点击",
    "ctr": "本周CTR",
    "cpc": "本周CPC",
    "cvr": "本周CVR",
    "orders": "本周订单",
    "sales": "本周销售额",
    "acos": "本周ACOS",
    "prev_orders": "上周订单",
    "prev_acos": "上周ACOS",
    "avg4_orders": "近4周均订单",
    "avg4_acos": "近4周均ACOS",
    "建议动作": "建议动作",
}
show_df = filtered[[c for c in display_cols if c in filtered.columns]].rename(columns=display_cols)
st.dataframe(
    show_df.style.format({
        "本周CTR": "{:.2%}", "本周CVR": "{:.2%}", "本周ACOS": "{:.1%}",
        "上周ACOS": "{:.1%}", "近4周均ACOS": "{:.1%}",
        "本周CPC": "${:.2f}", "本周销售额": "${:.2f}",
    }, na_rep="-"),
    use_container_width=True,
    height=600,
)

st.divider()
if st.button("📥 导出本次分析为 Excel", type="primary"):
    overview = pipeline.compute_overview(store, marketplace, product, settings)
    overview_export = pd.DataFrame([{
        "指标": "花费", "本周": overview.get("spend", 0), "上周": overview.get("prev_spend", 0),
    }]) if overview else pd.DataFrame()
    if overview:
        rows_ov = []
        for label, key in [("曝光", "impressions"), ("点击", "clicks"), ("花费", "spend"), ("销售额", "sales"),
                            ("订单", "orders"), ("CTR", "ctr"), ("CPC", "cpc"), ("CVR", "cvr"),
                            ("ACOS", "acos"), ("ROAS", "roas")]:
            rows_ov.append({"指标": label, "本周": overview.get(key, 0), "上周": overview.get(f"prev_{key}", 0),
                             "近4周均值": overview.get(f"avg4_{key}")})
        overview_export = pd.DataFrame(rows_ov)

    excel_bytes = build_excel_export(overview_export, df, recs)
    st.download_button(
        "点击下载 Excel 文件",
        data=excel_bytes,
        file_name=f"SP广告分析_{store}_{result.current_period[1]}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
