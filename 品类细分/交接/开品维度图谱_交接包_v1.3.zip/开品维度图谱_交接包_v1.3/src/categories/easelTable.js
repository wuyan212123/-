/* ======================================================================
   品类数据：桌面画架（画架系列）
   结构说明见 _template.js。数据快照：2026-11
   ====================================================================== */
CATS.push({
id:"easelTable", name:"桌面画架", en:"Tabletop Easel", updated:"2026-11",
series:"画架", pos:"放在桌上画小画、兼作展示；榉木 H 架是主力，画幅多在 24\" 以内",

scope:{
  def:"放在桌面上使用的画架，承托 24\" 以内的画布、画板或画本。包括桌面 H 架、桌面 A 字 / 三角小架、金属桌面三脚架、桌面倾斜画板，以及“桌面架 + 画布 + 画笔”的组合。",
  include:"上述画架单卖、多件装和组合套装。",
  exclude:"带抽屉的桌面画箱（见画箱）、5–9\" 迷你展示架（见展示画架）、儿童桌面画架（见儿童画架）。",
  adjacent:"平板 / 书本支架、桌面绘图台、画箱。",
  kw:["tabletop easel","table top easel","desk easel","tabletop drawing board","桌面画架","台式画架"]
},

rules:[
  "按结构分：桌面 H 架、桌面 A 字 / 三角架、金属桌面三脚架、桌面倾斜画板；带抽屉的画箱式桌面架归画箱。",
  "最大画布高度按页面原样记（英寸）；整架高度另记。",
  "角度调节记档位数和范围（如 7 档 41–78°、0–90°）；能到 0° 的记“可放平”。",
  "是否能锁定角度单独记：只靠摩擦或卡槽、没有锁扣的记“不可锁定”。",
  "是否需组装按页面写（MEEDEN 部分款免组装，AUREUO 需组装）。",
  "多件装按支数记；组合套装里的画布、画笔件数不计入画架数量。"
],

dims:[
 {g:"产品本体", about:"画架本身：结构、材质、尺寸、角度。", cats:[
  {t:"A 结构与材质", c:[
   {t:"结构类型", tag:"L1", c:[{t:"桌面 H 架",n:"MEEDEN、U.S. Art Supply、VISWIN"},{t:"桌面 A 字 / 三角架",n:"小型木架"},{t:"金属桌面三脚架",n:"U.S. Art Supply 13.5\""},{t:"桌面倾斜画板",n:"绘图板式"}]},
   {t:"材质", tag:"L1", c:[{t:"榉木"},{t:"松木"},{t:"竹"},{t:"钢 / 铁"},{t:"铝合金"}]}]},
  {t:"B 尺寸与角度", c:[
   {t:"最大画布高度", tag:"L2", c:[{t:"≤ 12\"",n:"金属三脚 14×11\""},{t:"13–20\"",n:"VISWIN 15\"、MEEDEN 20\""},{t:"21–25\"",n:"U.S. Art Supply 22\"、MEEDEN 23\"、AUREUO 24\""},{t:"26\" 以上"}]},
   {t:"整架高度", tag:"L3", c:[{t:"≤ 15\""},{t:"16–25\""},{t:"26–38\"",n:"U.S. Art Supply 38\""}]},
   {t:"角度调节", tag:"L2", c:[{t:"固定"},{t:"多档倾斜",n:"MEEDEN 7 档 41–78°"},{t:"可放平（0°）",n:"VISWIN 0–90°、MEEDEN 0–80°"}]},
   {t:"角度锁定", tag:"L3", def:"移动画板时会不会合上、倒下。", c:[{t:"卡槽 / 棘轮"},{t:"螺丝锁紧"},{t:"不可锁定",n:"部分金属折叠架"}]},
   {t:"防滑与稳定", tag:"L3", c:[{t:"防滑脚垫"},{t:"宽底座"},{t:"无"}]}]},
  {t:"C 合规", c:[
   {t:"安全与合规", tag:"L0", c:[{t:"Prop 65 警示"},{t:"边角打磨"},{t:"FSC 木材"}]}]}
 ]},
 {g:"销售形态", about:"怎么卖。", cats:[
  {t:"D 组合与数量", c:[
   {t:"销售组合", tag:"L2", c:[{t:"单个"},{t:"多件装（2–4 支）",n:"MEEDEN 金属 4 支装"},{t:"桌面架 + 画布 + 画笔",n:"AUREUO"}]},
   {t:"组装状态", tag:"L3", c:[{t:"免组装"},{t:"需组装"}]},
   {t:"便携", tag:"L3", c:[{t:"可折叠"},{t:"不可折叠"}]}]}
 ]},
 {g:"市场定位", about:"卖给谁、用在哪。", cats:[
  {t:"E 场景与人群", c:[
   {t:"使用场景", tag:"L3", c:[{t:"桌面小幅丙烯 / 油画"},{t:"水彩（需放平）"},{t:"速写本 / 手账"},{t:"展示小画、照片"},{t:"课堂 / 画室批量"}]},
   {t:"目标人群", tag:"L3", c:[{t:"成人初学者"},{t:"小空间画者"},{t:"老师"},{t:"礼品购买者"}]},
   {t:"价格带", tag:"L2", c:[{t:"< $15"},{t:"$15–30"},{t:"$30–60"},{t:"$60 以上"}]}]}
 ]}
],

types:[
 {g:"木质桌面架", about:"H 架、A 字架", items:[
  {t:"桌面 H 架", vol:"主流", volWhy:"MEEDEN、U.S. Art Supply、VISWIN、Falling in Art 多款在售。",
   combo:["桌面 H 架","榉木","画布 15–24\"","多档倾斜 / 可放平"],
   rep:"MEEDEN 重型桌面 H 架（≤ 20\"）、MEEDEN H 架（≤ 21\"）、U.S. Art Supply 38\" 桌面 H 架（≤ 22\"，可折叠）、VISWIN 25\"（≤ 15\"，0–90°）、Falling in Art 重型桌面 H 架",
   price:"US $25–60", who:"成人初学者、小空间画者", comp:"hi", compT:"高：品牌 + 白牌",
   pain:"画幅多在 24\" 以内；有的需组装", ev:["meedenTH","usasTH"], evl:"有来源",
   fig:{k:"stand",v:"tableh"},
   ex:[["meedenTH","重型，画布 ≤ 20\""],["usasTH","38\" 高，画布 ≤ 22\"，可折叠"],["viswinTH","25\"，画布 ≤ 15\"，0–90°"],["meedenTH21","画布 ≤ 21\""]],
   map:[["结构类型","桌面 H 架"],["材质","榉木"],["最大画布高度","13–20\" / 21–25\"","s"],["角度调节","多档倾斜 / 可放平（0°）","s"],["价格带","$30–60"]],
   pros:["稳","可调角度"], cons:["画幅有限"], up:["可锁定 + 更大画幅"], verdict:["谨慎","竞争高；升级方向见 ③ B。"], must:["写明画布上限"], plus:["免组装"], avoid:["—"]},
  {t:"桌面 A 字 / 三角小架", vol:"主流", volWhy:"小型木质桌面架大量在售，价格低。",
   combo:["桌面 A 字 / 三角架","松木 / 榉木","画布 ≤ 16\"","固定 / 少档"],
   rep:"ArtRight 小木架、各类 12–16\" 木质桌面三角架",
   price:"US $8–20", who:"初学者、展示小画", comp:"hi", compT:"高",
   pain:"轻、易倒；角度少", ev:["tableASearch"], evl:"部分来源",
   fig:{k:"stand",v:"tablea"},
   ex:[["artright","ArtRight 木质小画架"],["tableASearch","搜索页：wooden tabletop easel"]],
   map:[["结构类型","桌面 A 字 / 三角架"],["材质","松木 / 榉木"],["最大画布高度","13–20\""],["角度调节","固定"],["价格带","< $15 / $15–30"]],
   pros:["便宜"], cons:["不稳"], up:["—"], verdict:["不建议","低价红海。"], must:["—"], plus:["—"], avoid:["—"]}
 ]},
 {g:"金属桌面架", about:"兼作展示", items:[
  {t:"金属桌面三脚架", vol:"细分", volWhy:"U.S. Art Supply 13.5\"、MEEDEN 金属 4 支装、AROIC 14\" 多件装在售。",
   combo:["金属桌面三脚架","钢 / 铁","画布 ≤ 14\"","可折叠","多件装"],
   rep:"U.S. Art Supply 13.5\" 黑色金属桌面架（≤ 14×11\"，< 1 lb）、MEEDEN 金属桌面架 4 支装",
   price:"US $8–25", who:"展示小画、照片、标牌", comp:"hi", compT:"高",
   pain:"不能锁定角度，移动画板时会合上、倒下", ev:["tableFall"], evl:"部分来源",
   fig:{k:"stand",v:"tablemetal"},
   ex:[["usasMetal13","13.5\"，≤ 14×11\"，防滑脚"],["meedenMetal4","金属桌面架 4 支装"]],
   map:[["结构类型","金属桌面三脚架"],["材质","钢 / 铁"],["最大画布高度","≤ 12\""],["角度锁定","不可锁定","t"],["销售组合","多件装（2–4 支）"],["使用场景","展示小画、照片"]],
   pros:["轻、便宜"], cons:["易合上、倒"], up:["可锁定"], verdict:["谨慎","偏展示用途。"], must:["—"], plus:["—"], avoid:["—"]}
 ]},
 {g:"组合与画板", about:"套装、倾斜画板", items:[
  {t:"桌面架 + 画布画笔套装", vol:"细分", volWhy:"AUREUO 桌面 H 架 + 8×10\" 画布 + 10 支画笔等组合在售。",
   combo:["桌面 H 架","榉木","画布 ≤ 24\"","桌面架 + 画布 + 画笔"],
   rep:"AUREUO 桌面 H 架（≤ 24\"）+ 8×10\" 画布 + 10 支画笔",
   price:"US $25–45", who:"初学者、礼品", comp:"mid", compT:"中",
   pain:"只有工具，没有教程", ev:["aureuo"], evl:"有来源",
   fig:{k:"stand",v:"tableh",label:"桌面 H 架 + 画布 + 画笔"},
   ex:[["aureuo","画布 ≤ 24\"，含 8×10\" 画布和 10 支画笔；需组装"],["tableKitSearch","搜索页：tabletop easel kit"]],
   map:[["销售组合","桌面架 + 画布 + 画笔"],["组装状态","需组装","m"],["目标人群","成人初学者、礼品购买者"]],
   pros:["开箱能画"], cons:["无教程"], up:["加入入门课程"], verdict:["谨慎","对应 ③ C。"], must:["—"], plus:["课程"], avoid:["—"]},
  {t:"桌面倾斜画板", vol:"细分", volWhy:"桌面绘图板、可调角度画板在售，多用于素描、水彩、设计稿。",
   combo:["桌面倾斜画板","木 / 板材","可放平（0°）","可夹画本"],
   rep:"可调角度桌面绘图板（多档支腿）",
   price:"US $20–60", who:"素描、水彩、速写本用户", comp:"mid", compT:"中",
   pain:"不同画本、画纸固定方式不一", ev:["boardSearch"], evl:"部分来源",
   fig:{k:"stand",v:"board"},
   ex:[["boardSearch","搜索页：tabletop drawing board adjustable"],["jdBoard","京东：桌面画板支架"]],
   map:[["结构类型","桌面倾斜画板"],["角度调节","可放平（0°）"],["使用场景","水彩（需放平）、速写本 / 手账"]],
   pros:["适合水彩、素描"], cons:["不适合画布"], up:["夹画本结构（线索）"], verdict:["谨慎","需求待验证。"], must:["—"], plus:["—"], avoid:["—"]}
 ]}
],

opps:[
 {t:"可锁定角度的大画幅桌面架", gap:"痛点缺口", score:{d:3,c:3,x:3,s:4,p:3,e:3},
  why:"桌面架画幅多在 24\" 以内（MEEDEN 20–23\"、U.S. Art Supply 22\"、AUREUO 24\"）；金属折叠架有“移动画板就合上、倒下，没有锁定”的评论。能放 28\" 以上画布、角度能锁定、底座防滑的桌面架少。",
  spec:["桌面 H 架","榉木","画布 ≤ 30\"","卡槽 + 锁扣","防滑宽底座"], diff:"演示推、拍画板不倒", price:"US $45–65",
  risk:"大画幅桌面架重心高；要实测", verify:"抓桌面架差评里 tip over / falls / collapses / too small 的占比",
  from:"桌面 H 架、金属桌面三脚架", ev:["tableFall","meedenTH"], evl:"部分来源"},
 {t:"桌面画架 + 入门课程套装", gap:"场景缺口", score:{d:3,c:2,x:3,s:4,p:3,e:2},
  why:"已有“桌面架 + 画布 + 画笔”的组合（AUREUO），但没有课程。丙烯入门套装里加视频课的思路（见丙烯颜料）可以用到桌面画架上。",
  spec:["桌面 H 架","画布 3–5 块","画笔","颜料 12 色","分步视频课"], diff:"“跟着课画完第一幅”", price:"US $35–50",
  risk:"和丙烯套装重叠；课程成本", verify:"拉 tabletop easel kit 的搜索量和评论数",
  from:"桌面架 + 画布画笔套装", ev:["aureuo"], evl:"部分来源"},
 {t:"能夹速写本 / 手账的桌面架", state:"clue", gap:"场景缺口",
  why:"桌面架多为夹画布设计，速写本、手账、画纸块不好固定。是否有足够需求，证据不足。",
  spec:["桌面倾斜画板","画本夹 / 磁吸条"], verify:"拉 sketchbook stand、easel for sketchbook 的搜索量", from:"桌面倾斜画板", ev:["boardSearch"], evl:"经验判断"},
 {t:"可放平的桌面水彩架", state:"out", gap:"场景缺口",
  why:"最初判断桌面架只能竖着，水彩需要能放平。",
  outWhy:"核实后 VISWIN 写明 0–90°，MEEDEN 有 0–80° 款，已有人做。",
  spec:["桌面 H 架","可放平"], from:"桌面 H 架", ev:["viswinTH"], evl:"有来源"}
],

grids:[
 {id:"canvas",name:"结构 × 最大画布高度",q:"每种结构在哪个画幅上还没人做？",rowT:"结构类型",colT:"最大画布高度",
  cols:["≤ 12\"","13–20\"","21–25\"","26\" 以上"],
  rk:["tabletop h frame easel","small wooden tabletop easel","metal tabletop easel","tabletop drawing board"], ck:["12 inch","20 inch","24 inch","30 inch canvas"],
  rc:["桌面 H型 画架","桌面 小画架","金属 桌面 画架","桌面 画板"], cc:["","","",""],
  rows:[
   ["桌面 H 架",[["S1","—"],["R3","MEEDEN、VISWIN",{r:["meedenTH","viswinTH","meedenTH21"],t:["桌面 H 架"]}],["S3","U.S. Art Supply 22\"、AUREUO 24\"",{r:["usasTH","aureuo"]}],["L2","大画幅桌面架少",{o:"可锁定角度的大画幅桌面架",ev:"部分来源"}]]],
   ["桌面 A 字架",[["S3","—",{r:["artright"]}],["R3","—",{r:["tableASearch"],t:["桌面 A 字 / 三角小架"]}],["S1","—"],["X","—"]]],
   ["金属桌面架",[["R3","U.S. Art Supply 13.5\"",{r:["usasMetal13","meedenMetal4"],t:["金属桌面三脚架"]}],["S1","—"],["X","—"],["X","—"]]],
   ["倾斜画板",[["S1","—"],["S2","—",{r:["boardSearch"],t:["桌面倾斜画板"]}],["S1","—"],["X","—"]]]]},

 {id:"price",name:"结构 × 价格带",q:"每种结构在哪个价位还空着？",rowT:"结构类型",colT:"售价（美国站）",
  cols:["< $15","$15–30","$30–60","$60+"], price:["0-1500","1500-3000","3000-6000","6000-100000"],
  rk:["tabletop h frame easel","small wooden tabletop easel","metal tabletop easel","tabletop easel kit"],
  rc:["桌面 H型 画架","桌面 小画架","金属 桌面 画架","桌面 画架 套装"], cc:["","","",""],
  rows:[
   ["桌面 H 架",[["X","—"],["S3","—",{r:["viswinTH"]}],["R3","MEEDEN、U.S. Art Supply",{r:["meedenTH","usasTH"]}],["S1","MEEDEN PRO 大号"]]],
   ["桌面 A 字架",[["R3","—",{r:["artright","tableASearch"]}],["S2","—"],["X","—"],["X","—"]]],
   ["金属桌面架",[["R3","—",{r:["usasMetal13"]}],["S2","多件装",{r:["meedenMetal4"]}],["X","—"],["X","—"]]],
   ["组合套装",[["X","—"],["S2","AUREUO",{r:["aureuo"]}],["L2","带课程的少",{o:"桌面画架 + 入门课程套装",ev:"部分来源"}],["X","—"]]]]},

 {id:"angle",name:"结构 × 角度",q:"每种结构能调到什么角度？",rowT:"结构类型",colT:"角度调节",
  cols:["固定","多档倾斜","可放平"],
  rk:["tabletop h frame easel","small wooden tabletop easel","metal tabletop easel","tabletop drawing board"], ck:["","adjustable angle","flat"],
  rc:["桌面 H型 画架","桌面 小画架","金属 桌面 画架","桌面 画板"], cc:["","可调角度","可放平"],
  rows:[
   ["桌面 H 架",[["S1","—"],["R3","MEEDEN 7 档",{r:["meedenTH21","meedenTH"]}],["S2","VISWIN 0–90°",{r:["viswinTH"],o:"可放平的桌面水彩架"}]]],
   ["桌面 A 字架",[["R3","—",{r:["artright"]}],["S2","—"],["X","—"]]],
   ["金属桌面架",[["S2","—"],["S3","—",{r:["usasMetal13"]}],["X","—"]]],
   ["倾斜画板",[["X","—"],["S2","—"],["S2","—",{r:["boardSearch"]}]]]]},

 {id:"scene",name:"使用场景 × 关键卖点",q:"每个场景最在意的卖点，有没有产品明确满足？",rowT:"使用场景",colT:"关键卖点",
  cols:["稳不倒","角度可锁定","可放平","能夹画本","大画幅","多件装"],
  rk:["tabletop easel painting","watercolor tabletop easel","sketchbook stand","display tabletop easel","classroom tabletop easel"], ck:["sturdy","locking","flat","sketchbook holder","large canvas","pack"],
  rc:["桌面 画架","水彩 桌面 画架","速写本 支架","桌面 展示架","教室 桌面 画架"], cc:["稳","锁定","放平","夹画本","大画幅","多支装"],
  rows:[
   ["桌面小幅丙烯",[["S3","H 架",{r:["meedenTH"]}],["L2","—",{o:"可锁定角度的大画幅桌面架"}],["S1","—"],["X","—"],["L3","24\" 以上的少",{r:["usasTH","aureuo"],o:"可锁定角度的大画幅桌面架",ev:"部分来源"}],["S1","—"]]],
   ["水彩",[["S2","—"],["S1","—"],["S2","VISWIN、画板",{r:["viswinTH","boardSearch"]}],["L1","—"],["X","—"],["X","—"]]],
   ["速写本 / 手账",[["S1","—"],["S1","—"],["S1","—"],["L0","专门夹画本的少",{r:["boardSearch"],o:"能夹速写本 / 手账的桌面架",clue:true}],["X","—"],["X","—"]]],
   ["展示小画",[["L2","金属架易合上",{r:["usasMetal13"],o:"可锁定角度的大画幅桌面架",ev:"部分来源"}],["S1","—"],["X","—"],["X","—"],["S1","—"],["S3","—",{r:["meedenMetal4"]}]]],
   ["课堂批量",[["S1","—"],["S1","—"],["S1","—"],["S1","—"],["X","—"],["S2","—",{r:["meedenMetal4"]}]]]]}
],

refs:{
 meedenTH:["MEEDEN 重型桌面 H 架（≤ 20\"）","https://www.amazon.com/dp/B0CF1WXFH8"], meedenTH21:["MEEDEN 桌面 H 架（≤ 21\"）","https://www.amazon.com/clp/B09TPH9VQR"], usasTH:["U.S. Art Supply 38\" 桌面 H 架（≤ 22\"）","https://www.amazon.com/dp/B00L5P86SM"], viswinTH:["VISWIN 25\" 桌面 H 架（0–90°）","https://www.amazon.com/dp/B0CYSRSJ3J"],
 aureuo:["AUREUO 桌面 H 架 + 画布 + 画笔","https://us.amazon.com/dp/B08XM5DHX9"], artright:["ArtRight 木质小画架","https://www.amazon.com/clp/B08W9QH3ST"],
 usasMetal13:["U.S. Art Supply 13.5\" 金属桌面架","https://www.amazon.com/dp/B00RLZAXU4"], meedenMetal4:["MEEDEN 金属桌面架 4 支装","https://www.amazon.com/clp/B0CWNG1ZHH"],
 tableASearch:["Amazon 搜索：wooden tabletop easel","https://www.amazon.com/s?k=small+wooden+tabletop+easel"], tableKitSearch:["Amazon 搜索：tabletop easel kit","https://www.amazon.com/s?k=tabletop+easel+painting+kit"],
 boardSearch:["Amazon 搜索：tabletop drawing board adjustable","https://www.amazon.com/s?k=tabletop+drawing+board+adjustable"], jdBoard:["京东 · 桌面画板支架（搜索页）","https://search.jd.com/Search?keyword=%E6%A1%8C%E9%9D%A2%E7%94%BB%E6%9D%BF%E6%94%AF%E6%9E%B6&enc=utf-8"]
},

src:{
 meedenTH:["MEEDEN 桌面 H 架（Amazon）","https://www.amazon.com/dp/B0CF1WXFH8"],
 usasTH:["U.S. Art Supply 桌面 H 架（Amazon）","https://www.amazon.com/dp/B00L5P86SM"],
 viswinTH:["VISWIN 25\" 桌面 H 架（Amazon，0–90°）","https://www.amazon.com/dp/B0CYSRSJ3J"],
 aureuo:["AUREUO 桌面架套装（Amazon）","https://us.amazon.com/dp/B08XM5DHX9"],
 tableFall:["Staples 评论：桌面架移动画板会合上、倒下","https://www.staples.com/ptd/review/1682317"],
 tableASearch:["Amazon 搜索：wooden tabletop easel","https://www.amazon.com/s?k=small+wooden+tabletop+easel"],
 boardSearch:["Amazon 搜索：tabletop drawing board","https://www.amazon.com/s?k=tabletop+drawing+board+adjustable"]
}
});
