/* ======================================================================
   品类数据：户外写生画架（画架系列）
   结构说明见 _template.js。数据快照：2026-11
   ====================================================================== */
CATS.push({
id:"easelPlein", name:"户外写生画架", en:"Field / Plein Air Easel", updated:"2026-11",
series:"画架", pos:"轻、能背出门；铝合金三脚架便宜但伸长会晃，水彩写生要能放平",

scope:{
  def:"带出门写生用的轻便画架：铝合金三脚写生架、平放水彩写生架、写生专用三脚架（配画箱）、写生全套（画架 + 凳 + 包），以及国内写生画架。",
  include:"上述画架单卖、多件装和写生套装。",
  exclude:"法式画箱、写生画箱 Pochade（见画箱）；纯展示用的金属指示牌架（见展示画架）。",
  adjacent:"写生凳、画箱、湿画板携带箱、相机三脚架。",
  kw:["field easel","plein air easel","tripod easel","watercolor easel portable","写生画架","户外画架","铝合金画架"]
},

rules:[
  "按结构分：铝合金三脚写生架、平放水彩写生架、写生专用三脚架、写生全套、国内写生画架；带盒子的法式画箱、Pochade 归画箱。",
  "重量统一记 kg（页面写 lbs 的换算后保留原值）；画架本体和整套分开记。",
  "高度范围按页面原样记（如 17–66\"、25–72\"）；收纳长度单独记（如折叠后 18\"、21\"）。",
  "承重只记页面写明的数字（如 25 lbs）。",
  "“可放平”指画板能调到水平，用于水彩；只写“可倾斜”不算。",
  "多件装（如 Ohuhu 2 支装）按支数记，价格按单支折算后另记。"
],

dims:[
 {g:"产品本体", about:"画架本身：结构、材质、重量、高度、角度。", cats:[
  {t:"A 结构与材质", c:[
   {t:"结构类型", tag:"L1", c:[{t:"铝合金三脚写生架",n:"Ohuhu、KINGART、U.S. Art Supply"},{t:"平放水彩写生架",n:"PLEINLY、磁吸写生板、MEEDEN"},{t:"写生专用三脚架",n:"New Wave u.go、Mabef"},{t:"写生全套",n:"画架 + 凳 + 包"},{t:"国内写生画架",n:"铝合金 / 铁 + 画板"}]},
   {t:"材质", tag:"L1", c:[{t:"铝合金"},{t:"钢 / 铁"},{t:"榉木"},{t:"碳纤维"}]}]},
  {t:"B 尺寸与重量", c:[
   {t:"重量", tag:"L2", c:[{t:"≤ 1 kg",n:"KINGART < 2 lbs"},{t:"1–2 kg",n:"MEEDEN 水彩三脚 2 kg、PLEINLY 三脚 945 g + 画板 450 g"},{t:"2 kg 以上"}]},
   {t:"高度范围", tag:"L3", c:[{t:"17–66\""},{t:"18–66\""},{t:"25–72\"",n:"Ohuhu"}]},
   {t:"收纳长度", tag:"L3", c:[{t:"≤ 18\"",n:"U.S. Art Supply"},{t:"19–25\"",n:"KINGART 21\""},{t:"25\" 以上"}]},
   {t:"承重", tag:"L3", c:[{t:"≤ 10 lbs"},{t:"10–25 lbs",n:"25 lbs 款"},{t:"未披露"}]},
   {t:"最大画布高度", tag:"L3", c:[{t:"≤ 36\"",n:"KINGART"},{t:"37–38\""},{t:"画本 / 画纸块 ≤ 16×12\"",n:"PLEINLY"}]}]},
  {t:"C 调节与稳定", c:[
   {t:"角度调节", tag:"L2", c:[{t:"竖直"},{t:"可倾斜"},{t:"可放平（0°）",n:"PLEINLY、磁吸写生板"}]},
   {t:"稳定措施", tag:"L2", def:"户外有风，伸长后会晃。", c:[{t:"每条腿单独调（适应不平地面）",n:"Ohuhu"},{t:"中心挂钩可挂配重"},{t:"防滑脚 / 地钉"},{t:"无"}]},
   {t:"安装方式", tag:"L3", c:[{t:"弹簧顶夹"},{t:"1/4\" 相机螺口",n:"配写生板 / 画箱"},{t:"快装板"}]}]},
  {t:"D 合规", c:[
   {t:"安全与合规", tag:"L0", c:[{t:"Prop 65 警示"},{t:"锋利边角"}]}]}
 ]},
 {g:"销售形态", about:"怎么卖。", cats:[
  {t:"E 组合与数量", c:[
   {t:"销售组合", tag:"L2", c:[{t:"单支"},{t:"2 支装",n:"Ohuhu"},{t:"画架 + 收纳包"},{t:"写生全套（架 + 凳 + 包 + 画板）",n:"PLEINLY"}]},
   {t:"随附配件", tag:"L3", c:[{t:"收纳包"},{t:"托盘"},{t:"湿画携带夹"},{t:"夹子"},{t:"调色盘"}]}]}
 ]},
 {g:"市场定位", about:"卖给谁、用在哪。", cats:[
  {t:"F 场景与人群", c:[
   {t:"使用场景", tag:"L3", c:[{t:"油画 / 丙烯写生"},{t:"水彩写生"},{t:"速写"},{t:"旅行"},{t:"艺考写生"},{t:"兼作展示"}]},
   {t:"目标人群", tag:"L3", c:[{t:"写生爱好者"},{t:"水彩画者"},{t:"美术生"},{t:"旅行者"}]},
   {t:"价格带", tag:"L2", c:[{t:"< $25"},{t:"$25–50"},{t:"$50–100"},{t:"$100 以上"}]}]}
 ]}
],

types:[
 {g:"三脚写生架", about:"铝合金为主", items:[
  {t:"铝合金三脚写生架", vol:"主流", volWhy:"Ohuhu 2 支装、KINGART、U.S. Art Supply、abitcha、AROIC 等大量在售，兼作展示。",
   combo:["铝合金三脚写生架","铝合金","17–72\"","≤ 1–1.2 kg","弹簧顶夹","收纳包"],
   rep:"Ohuhu 72\" 2 支装（每条腿单独调）、KINGART 18–66\"（< 2 lbs，画布 ≤ 36\"）、U.S. Art Supply 66\"（带托盘，折叠 18\"）、17–66\" 款（承重 25 lbs）",
   price:"US $15–40", who:"写生爱好者、展示", comp:"hi", compT:"高：白牌多",
   pain:"伸长后晃；有风会倒；零件松脱", ev:["cheapWobble","frenchWobble"], evl:"部分来源",
   fig:{k:"stand",v:"tripod"},
   ex:[["ohuhu2","72\" 2 支装，每条腿单独调"],["kingartT","18–66\"，< 2 lbs，画布 ≤ 36\""],["usasT66","66\"，带托盘，折叠 18\""],["triBag","17–66\"，承重 25 lbs，1.18 kg"]],
   map:[["结构类型","铝合金三脚写生架"],["材质","铝合金"],["重量","≤ 1 kg / 1–2 kg","s"],["高度范围","17–66\" / 25–72\"","s"],["承重","10–25 lbs","s"],["稳定措施","每条腿单独调（Ohuhu）","s"],["使用场景","油画 / 丙烯写生、兼作展示"]],
   pros:["轻、便宜","兼作展示"], cons:["伸长后晃","风大易倒"],
   up:["加粗腿 + 配重挂钩 + 地钉"], verdict:["可做","对应 ③ B“防风稳固的铝合金写生架”。"], must:["写明承重和重量"], plus:["配重挂钩"], avoid:["只写 sturdy"]},
  {t:"写生专用三脚架（配画箱）", vol:"小众", volWhy:"New Wave u.go 旅行三脚架、Mabef M/A30 木三脚架在售，配 Pochade 画箱使用。",
   combo:["写生专用三脚架","铝合金 / 榉木","1/4\" 相机螺口","承重 8–12 kg"],
   rep:"New Wave u.go LCS1（2.9 lbs，承重 26.5 lbs）、Mabef M/A30 木三脚架（约 1.3 kg，承重 8 kg）",
   price:"US $60–150", who:"用 Pochade 画箱的写生画家", comp:"lo", compT:"低",
   pain:"贵；普通相机三脚架承重不够", ev:["pochadeTripod"], evl:"有来源",
   fig:{k:"stand",v:"pochade",label:"写生三脚架（配画箱）"},
   ex:[["uGoTripod","2.9 lbs，承重 26.5 lbs，通用 1/4\" 螺口"],["mabef30","约 1.3 kg，承重 8 kg"]],
   map:[["结构类型","写生专用三脚架"],["安装方式","1/4\" 相机螺口","m"],["承重","10–25 lbs","m"]],
   pros:["稳、轻"], cons:["贵"], up:["—"], verdict:["谨慎","依附画箱市场。"], must:["—"], plus:["—"], avoid:["—"]}
 ]},
 {g:"水彩写生", about:"能放平", items:[
  {t:"平放水彩写生架", vol:"细分", volWhy:"PLEINLY 水彩写生架、磁吸写生板（配相机三脚架）、MEEDEN 水彩三脚架在售。",
   combo:["平放水彩写生架","铝合金 + 画板","可放平（0°）","1/4\" 相机螺口","≤ 16×12\" 画本"],
   rep:"PLEINLY 水彩写生架（三脚 945 g + 画板 450 g，≤ 16×12\"）、磁吸写生板（11.8×15.7\"，1.7 lb，三脚架另购）、MEEDEN 水彩旅行三脚架（2 kg）",
   price:"US $40–120", who:"水彩写生、速写", comp:"mid", compT:"中：品牌少",
   pain:"部分款三脚架另购；全套价格不低", ev:["wcEaselLink"], evl:"有来源",
   fig:{k:"stand",v:"wc"},
   ex:[["pleinly","可横竖、可放平，≤ 16×12\""],["magSketch","磁吸写生板，可放平，三脚架另购"],["meedenWC","水彩旅行三脚架，2 kg"]],
   map:[["结构类型","平放水彩写生架"],["角度调节","可放平（0°）","m"],["重量","1–2 kg","m"],["最大画布高度","画本 / 画纸块 ≤ 16×12\"","m"],["安装方式","1/4\" 相机螺口"]],
   pros:["专为水彩"], cons:["价格高或需另购三脚架"], up:["平价轻量全套"], verdict:["可做","对应 ③ B“平价轻量的水彩写生架”。"], must:["写明全套重量"], plus:["湿画携带夹"], avoid:["三脚架另购不写清"]},
  {t:"写生全套（架 + 凳 + 包）", vol:"细分", volWhy:"PLEINLY 水彩写生全套（三脚架、凳、包、全棉画本、画板、夹子、调色盘）在售。",
   combo:["写生全套","铝合金","写生全套（架 + 凳 + 包 + 画板）"],
   rep:"PLEINLY 水彩写生全套（含湿画携带夹、凳子、肩包、100% 棉画本、9 个夹子、2 个调色盘）",
   price:"US $80–150", who:"水彩写生入门", comp:"lo", compT:"低",
   pain:"贵", ev:["wcEaselLink"], evl:"有来源",
   fig:{k:"stand",v:"kit"},
   ex:[["pleinlySet","三脚架 + 凳 + 包 + 画本 + 画板"],["pleinly","画架单卖款"]],
   map:[["销售组合","写生全套（架 + 凳 + 包 + 画板）"],["随附配件","收纳包、湿画携带夹、夹子、调色盘"]],
   pros:["一次买齐"], cons:["贵"], up:["—"], verdict:["谨慎","已有品牌（③ 中已排除）。"], must:["—"], plus:["—"], avoid:["—"]}
 ]},
 {g:"国内写生", about:"美术生写生", items:[
  {t:"国内写生画架（铝合金 / 铁 + 画板）", vol:"主流", volWhy:"国内美术生写生常用伸缩铝合金 / 铁画架，常和画板、画包一起卖（京东多款）。",
   combo:["国内写生画架","铝合金 / 铁","画架 + 画板 + 包"],
   rep:"伸缩铝合金写生画架、铁画架 + 4K 画板 + 画包（京东多店铺）",
   price:"¥30–150", who:"美术生、写生课", comp:"hi", compT:"高",
   pain:"晃；锁扣易坏", ev:["jdPlein"], evl:"部分来源",
   fig:{k:"stand",v:"cn",label:"写生画架 + 画板"},
   ex:[["jdPlein","京东：写生画架"],["jdPleinSet","京东：写生画架套装"]],
   map:[["结构类型","国内写生画架"],["销售组合","画架 + 收纳包"],["使用场景","艺考写生"]],
   pros:["需求大"], cons:["价格低"], up:["写生全套（线索）"], verdict:["谨慎","价格战。"], must:["—"], plus:["—"], avoid:["—"]}
 ]}
],

opps:[
 {t:"防风稳固的铝合金写生架", gap:"痛点缺口", score:{d:3,c:3,x:4,s:4,p:3,e:3},
  why:"铝合金三脚架便宜、销量大，但评论反复提到伸长后晃、户外有风会倒。只有少数款写了“每条腿单独调”；中心配重挂钩、地钉、承重数字很少被当作主卖点。",
  spec:["铝合金三脚","加粗腿管","中心配重挂钩","地钉 + 防滑脚","写明承重 ≥ 25 lbs","收纳包"], diff:"风扇 / 户外实拍对比不倒", price:"US $28–40",
  risk:"重量会增加；同质化快", verify:"抓三脚写生架 Top 20 差评里 wobbly / wind / flimsy / broke 的占比",
  from:"铝合金三脚写生架", ev:["cheapWobble","frenchWobble","signWind"], evl:"部分来源"},
 {t:"平价轻量的水彩写生架", gap:"价格带缺口", score:{d:3,c:3,x:4,s:3,p:3,e:3},
  why:"水彩写生需要画板能放平。现有选择：PLEINLY（全套价格高）、磁吸写生板（三脚架另购）、MEEDEN 水彩三脚架（2 kg）。“含三脚架、全套 1.5 kg 以内、$50 以下”的款还少。",
  spec:["平放水彩写生架","铝合金三脚架（含）","画板夹画本 ≤ 12×16\"","全套 ≤ 1.5 kg"], diff:"“一个包装全部、能放平、背着走”", price:"US $40–55",
  risk:"轻量和稳定冲突；画板精度要求高", verify:"拉 watercolor easel portable 搜索量；统计 Top 30 里含三脚架、$50 以下的数量",
  from:"平放水彩写生架", ev:["wcEaselLink"], evl:"有来源"},
 {t:"国内写生全套（画架 + 凳 + 包 + 画板）", state:"clue", gap:"场景缺口",
  why:"国内美术生写生常分开买画架、画板、画包、写生凳。是否有足够需求做成一体套装，证据不足。",
  spec:["写生画架","画板","画包","写生凳"], verify:"在京东 / 淘宝搜“写生套装 画架 凳”看销量", from:"国内写生画架（铝合金 / 铁 + 画板）", ev:["jdPlein"], evl:"经验判断"},
 {t:"写生全套（架 + 凳 + 包，美国站）", state:"out", gap:"场景缺口",
  why:"最初判断美国站缺少画架、凳、包一起卖的写生全套。",
  outWhy:"核实后 PLEINLY 已有含三脚架、凳、肩包、画本、画板的水彩写生全套。",
  spec:["写生全套"], from:"写生全套（架 + 凳 + 包）", ev:["wcEaselLink"], evl:"有来源"}
],

grids:[
 {id:"weight",name:"结构 × 重量",q:"每种结构在哪个重量段还没人做？",rowT:"结构类型",colT:"重量",
  cols:["≤ 1 kg","1–2 kg","2 kg 以上"],
  rk:["aluminum tripod field easel","watercolor plein air easel","pochade tripod","plein air easel kit"], ck:["lightweight","1 kg","heavy duty"],
  rc:["铝合金 写生 画架","水彩 写生 画架","写生 三脚架","写生 套装"], cc:["轻便","",""],
  rows:[
   ["铝合金三脚",[["R3","KINGART、多数白牌",{r:["kingartT","triBag"],t:["铝合金三脚写生架"]}],["S2","—",{r:["ohuhu2"]}],["L1","—"]]],
   ["平放水彩架",[["L2","磁吸写生板（三脚架另购）",{r:["magSketch"]}],["L3","含三脚架的平价款少",{r:["pleinly","meedenWC"],t:["平放水彩写生架"],o:"平价轻量的水彩写生架",ev:"有来源"}],["S1","—"]]],
   ["写生三脚架",[["X","—"],["S2","u.go、Mabef",{r:["uGoTripod","mabef30"],t:["写生专用三脚架（配画箱）"]}],["S1","—"]]],
   ["写生全套",[["X","—"],["S1","—"],["S1","PLEINLY",{r:["pleinlySet"],t:["写生全套（架 + 凳 + 包）"],o:"写生全套（架 + 凳 + 包，美国站）"}]]]]},

 {id:"price",name:"结构 × 价格带",q:"每种结构在哪个价位还空着？",rowT:"结构类型",colT:"售价（美国站）",
  cols:["< $25","$25–50","$50–100","$100+"], price:["0-2500","2500-5000","5000-10000","10000-100000"],
  rk:["aluminum tripod field easel","watercolor plein air easel","pochade tripod","plein air easel kit"],
  rc:["铝合金 写生 画架","水彩 写生 画架","写生 三脚架","写生 套装"], cc:["","","",""],
  rows:[
   ["铝合金三脚",[["R3","—",{r:["kingartT","triBag"]}],["S3","2 支装",{r:["ohuhu2","usasT66"]}],["S1","—"],["X","—"]]],
   ["平放水彩架",[["S1","写生板（不含三脚架）",{r:["magSketch"]}],["L2","含三脚架的少",{o:"平价轻量的水彩写生架",ev:"有来源"}],["S2","PLEINLY、MEEDEN",{r:["pleinly","meedenWC"]}],["S1","—"]]],
   ["写生三脚架",[["X","—"],["S1","—"],["S2","u.go",{r:["uGoTripod"]}],["S1","Mabef",{r:["mabef30"]}]]],
   ["写生全套",[["X","—"],["X","—"],["S1","—"],["S1","PLEINLY",{r:["pleinlySet"]}]]]]},

 {id:"angle",name:"结构 × 稳定措施",q:"每种结构有没有做防风、防晃？",rowT:"结构类型",colT:"稳定措施",
  cols:["每条腿单独调","配重挂钩","地钉 / 防滑脚"],
  rk:["aluminum tripod field easel","watercolor plein air easel","plein air easel"], ck:["independent legs","weight hook","stakes"],
  rc:["铝合金 写生 画架","水彩 写生 画架","写生 画架"], cc:["","挂钩","地钉"],
  rows:[
   ["铝合金三脚",[["S2","Ohuhu",{r:["ohuhu2"]}],["L3","少有配重挂钩",{r:["kingartT","usasT66"],o:"防风稳固的铝合金写生架",ev:"部分来源"}],["L2","—",{o:"防风稳固的铝合金写生架"}]]],
   ["平放水彩架",[["S1","—",{r:["pleinly"]}],["L1","—"],["S1","—"]]],
   ["国内写生架",[["S1","—",{r:["jdPlein"]}],["L1","—"],["S1","—"]]]]},

 {id:"scene",name:"使用场景 × 关键卖点",q:"每个场景最在意的卖点，有没有产品明确满足？",rowT:"使用场景",colT:"关键卖点",
  cols:["轻","稳 / 防风","可放平","收纳快","带凳和包","价格低"],
  rk:["plein air oil painting easel","watercolor plein air easel","sketching easel","travel easel","art student plein air easel"], ck:["lightweight","stable wind","flat","quick setup","with stool bag","cheap"],
  rc:["油画 写生 画架","水彩 写生 画架","速写 画架","旅行 画架","美术生 写生 画架"], cc:["轻便","稳","放平","收纳","凳 包","便宜"],
  rows:[
   ["油画 / 丙烯写生",[["S3","—",{r:["kingartT"]}],["L3","伸长后晃、风大会倒",{r:["ohuhu2","usasT66"],o:"防风稳固的铝合金写生架",ev:"部分来源"}],["X","—"],["S2","—"],["S1","—"],["R3","—",{r:["triBag"]}]]],
   ["水彩写生",[["S2","—",{r:["magSketch"]}],["S1","—"],["L3","含三脚架的平价款少",{r:["pleinly","meedenWC"],o:"平价轻量的水彩写生架",ev:"有来源"}],["S1","—"],["S1","PLEINLY",{r:["pleinlySet"]}],["L2","—",{o:"平价轻量的水彩写生架"}]]],
   ["速写",[["S2","—"],["S1","—"],["S2","—",{r:["magSketch"]}],["S2","—"],["X","—"],["S2","—"]]],
   ["旅行",[["S2","u.go",{r:["uGoTripod"]}],["S1","—"],["S1","—"],["S2","—"],["S1","—"],["S1","—"]]],
   ["艺考写生",[["S1","—"],["L2","—",{r:["jdPlein"]}],["X","—"],["S1","—"],["L0","国内一体套装少",{r:["jdPleinSet"],o:"国内写生全套（画架 + 凳 + 包 + 画板）",clue:true}],["R3","—",{r:["jdPlein"]}]]]]}
],

refs:{
 ohuhu2:["Ohuhu 72\" 铝合金三脚架 2 支装","https://www.amazon.com/dp/B075D9C4WG"], kingartT:["KINGART 铝合金三脚架 18–66\"","https://www.amazon.com/dp/B09FFJJ9KY"], usasT66:["U.S. Art Supply 66\" 铝合金三脚架","https://www.amazon.com/dp/B00LFPKJ1Y"], triBag:["17–66\" 铝合金三脚架（承重 25 lbs）","https://www.amazon.com/clp/B07S9RSZ8N"],
 uGoTripod:["New Wave u.go 写生三脚架","https://www.amazon.com/dp/B082FNKW75"], mabef30:["Mabef M/A30 木三脚架","https://www.amazon.com/dp/B0047XEVU6"],
 pleinly:["PLEINLY 水彩写生架","https://www.amazon.com/dp/B0FF48DJ6Y"], pleinlySet:["PLEINLY 水彩写生全套（架 + 凳 + 包）","https://www.amazon.com/dp/B0DCWXJMGR"], magSketch:["磁吸写生板（配相机三脚架）","https://www.amazon.com/dp/B0D7HKQWGC"], meedenWC:["MEEDEN 水彩旅行三脚架","https://www.amazon.com/dp/B07WG7C4BF"],
 jdPlein:["京东 · 写生画架（搜索页）","https://search.jd.com/Search?keyword=%E5%86%99%E7%94%9F%E7%94%BB%E6%9E%B6&enc=utf-8"], jdPleinSet:["京东 · 写生画架套装（搜索页）","https://search.jd.com/Search?keyword=%E5%86%99%E7%94%9F%E7%94%BB%E6%9E%B6%E5%A5%97%E8%A3%85&enc=utf-8"]
},

src:{
 cheapWobble:["零售评论：廉价三脚画架越伸越晃","https://www.virtualartacademy.com/winsor-newton-easel/"],
 frenchWobble:["WetCanvas：写生画架腿晃、重量讨论","https://www.wetcanvas.com/forums/topic/french-easel-or-guerrilla-painter"],
 signWind:["展示架户外防风：后腿加沙袋","https://icustomlabel.com/blogs/wedding-decor-and-gifts/how-to-display-wedding-welcome-sign-easels"],
 pochadeTripod:["New Wave u.go 三脚架（Amazon，承重 26.5 lbs）","https://www.amazon.com/dp/B082FNKW75"],
 wcEaselLink:["PLEINLY 水彩写生全套（Amazon）","https://www.amazon.com/dp/B0DCWXJMGR"],
 jdPlein:["京东 · 写生画架（搜索页）","https://search.jd.com/Search?keyword=%E5%86%99%E7%94%9F%E7%94%BB%E6%9E%B6&enc=utf-8"]
}
});
