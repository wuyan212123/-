/* ======================================================================
   品类数据：落地画架（画架系列）
   结构说明见 _template.js。数据快照：2026-11
   ====================================================================== */
CATS.push({
id:"easelFloor", name:"落地画架", en:"Floor / Studio Easel", updated:"2026-11",
series:"画架", pos:"画室主力；A 字架便宜但伸高会晃，榉木 H 架稳但贵、重",

scope:{
  def:"放在地上、站着或坐着画的画架，承托画布、画板。包括 A 字三脚架、H 架、摇柄升降 H 架、可平放多功能架、带抽屉的画室架，以及国内美术生常用的铁画架 / 木画架。",
  include:"上述画架单卖、多件装，以及“画架 + 画板 / 画布”的组合。",
  exclude:"铝合金三脚写生架（见户外写生画架）、法式画箱（见画箱）、儿童画架（见儿童画架）、婚礼展示架（见展示画架）。",
  adjacent:"画板、画布、画凳、画室边柜（见画柜）。",
  kw:["floor easel","h-frame easel","a-frame easel","studio easel","画架","落地画架","H 型画架"]
},

rules:[
  "按结构分：A 字架（三脚、前两腿 + 后一腿）、H 架（两根立柱 + H 形底座）、摇柄 H 架、可平放多功能架、带抽屉画室架、铁画架；同一品牌不同结构分开记。",
  "“最大画布高度”和“整体高度范围”分开记，单位统一为英寸（国内页面按 cm 原样记，并注明）。",
  "承重只记页面写明的数字（如 33 lbs / 15 kg）；没写记“未披露”，不要用画布尺寸推算。",
  "角度调节分三档：固定、前后倾斜、可放平（0°）。只写“可倾斜”不算可平放。",
  "调节方式按实物结构记：翼形螺母、棘轮 / 卡槽、摇柄、弹簧夹；“免工具”要看是否真的不需要拧螺丝。",
  "整装发货 / 需组装分开记；需组装的记录零件数或是否有编号贴纸（VISWIN 有编号贴纸）。",
  "套装里的画布、画板、画笔件数不计入画架数量。"
],

dims:[
 {g:"产品本体", about:"画架本身：结构、材质、尺寸承重、调节方式。", cats:[
  {t:"A 结构与材质", c:[
   {t:"结构类型", tag:"L1", def:"决定稳定性、占地和价格，是最主要的分类维度。",
    kw:["a-frame easel","h-frame easel","crank easel","tilting flat easel"],
    c:[{t:"A 字架",n:"三点着地，轻、便宜"},{t:"H 架",n:"两根立柱 + H 形底座，稳"},{t:"摇柄 H 架",n:"摇柄升降，重型"},{t:"可平放多功能架",n:"可从竖直调到放平"},{t:"带抽屉画室架",n:"H 架 + 抽屉 / 层板"},{t:"铁画架",n:"国内美术生常用，可折叠"}]},
   {t:"材质", tag:"L1", c:[{t:"松木",n:"便宜、轻"},{t:"榉木",n:"中高端主流"},{t:"橡木 / 硬木"},{t:"铁 / 钢"},{t:"铝合金"}]},
   {t:"表面处理", tag:"L3", c:[{t:"原木打磨"},{t:"上油",n:"Creative Mark 上油榉木"},{t:"漆面（黑 / 白 / 胡桃色）"}]}]},
  {t:"B 尺寸与承重", c:[
   {t:"最大画布高度", tag:"L2", rule:"按页面原样记，统一换成英寸。",
    c:[{t:"≤ 36\"",n:"Somime A 字架"},{t:"37–50\"",n:"VISWIN 49\"、KINGART 40\""},{t:"51–77\"",n:"MEEDEN 77\""},{t:"78\" 以上",n:"DJAR、Somime H 架 78\""}]},
   {t:"整体高度范围", tag:"L3", c:[{t:"≤ 65\""},{t:"53–95\""},{t:"60–102\"",n:"Creative Mark Carolina"},{t:"更高（重型）"}]},
   {t:"承重", tag:"L2", rule:"只记页面写明的数字。", c:[{t:"≤ 15 lbs"},{t:"15–33 lbs",n:"MEEDEN 33 lbs、松木 A 字架 33 lbs"},{t:"33 lbs 以上"},{t:"未披露"}]},
   {t:"整架重量", tag:"L3", c:[{t:"≤ 5 lbs",n:"松木 A 字架"},{t:"10–25 lbs",n:"Creative Mark 24 lbs"},{t:"25 lbs 以上",n:"U.S. Art Supply 重型 35 lbs"}]}]},
  {t:"C 调节与稳定", c:[
   {t:"角度调节", tag:"L2", c:[{t:"固定"},{t:"前后倾斜"},{t:"可放平（0°）",n:"MEEDEN Versatile"}]},
   {t:"调节方式", tag:"L2", def:"翼形螺母便宜但易滑丝；棘轮 / 卡槽、摇柄调节快。",
    c:[{t:"翼形螺母"},{t:"棘轮 / 卡槽"},{t:"摇柄"},{t:"弹簧夹（顶夹）"}]},
   {t:"稳定结构", tag:"L3", c:[{t:"三点着地 + 后支腿"},{t:"H 形底座"},{t:"带锁万向轮"},{t:"可加配重"}]},
   {t:"同时放画数", tag:"L3", c:[{t:"1 幅"},{t:"2 幅（上下）",n:"MEEDEN 可放 2 幅"}]}]},
  {t:"D 合规", c:[
   {t:"安全与合规", tag:"L0", rule:"木材涂层注意 Prop 65；边角无毛刺；带轮款要能锁定。",
    c:[{t:"Prop 65 警示"},{t:"FSC 木材"},{t:"边角打磨"},{t:"倾倒警示"}]}]}
 ]},
 {g:"销售形态", about:"怎么卖：单卖还是组合、组装状态、配件。", cats:[
  {t:"E 组合与数量", c:[
   {t:"销售组合", tag:"L2", c:[{t:"单个画架"},{t:"2 件装"},{t:"画架 + 画板",n:"国内美术生"},{t:"画架 + 画布 + 颜料套装"}]},
   {t:"组装状态", tag:"L3", c:[{t:"整装发货",n:"Creative Mark Carolina"},{t:"需组装（有编号）",n:"VISWIN"},{t:"需组装（说明简单）"}]}]},
  {t:"F 收纳与配件", c:[
   {t:"收纳配件", tag:"L3", c:[{t:"托盘"},{t:"笔槽"},{t:"抽屉"},{t:"层板"},{t:"无"}]},
   {t:"便携", tag:"L3", c:[{t:"可折叠收纳"},{t:"带轮可推"},{t:"不可折叠"}]}]}
 ]},
 {g:"市场定位", about:"卖给谁、用在哪。", cats:[
  {t:"G 等级", c:[
   {t:"产品等级", tag:"L1", c:[{t:"入门（松木、铁）",n:"$25–60"},{t:"中级（榉木 A 字 / H 架）",n:"$60–150"},{t:"专业（重型、摇柄）",n:"$150 以上"}]}]},
  {t:"H 场景与人群", c:[
   {t:"使用场景", tag:"L3", c:[{t:"画室油画 / 丙烯"},{t:"水彩 / 素描（需放平）"},{t:"艺考素描"},{t:"课堂"},{t:"小户型家用"},{t:"兼作展示"}]},
   {t:"目标人群", tag:"L3", c:[{t:"成人初学者"},{t:"进阶爱好者"},{t:"专业画家"},{t:"美术生"},{t:"老师 / 画室"}]}]}
 ]}
],

types:[
 {g:"A 字架", about:"三点着地，入门主力", items:[
  {t:"木质 A 字画架（松木 / 榉木）", vol:"主流", volWhy:"Somime、VISWIN、BAHOM、KINGART、Falling in Art 等大量在售。",
   combo:["A 字架","松木 / 榉木","画布 36–49\"","翼形螺母","可折叠"],
   rep:"Somime 榉木 A 字架（画布 ≤ 36\"）、VISWIN 可倾斜 A 字架（65–89\"，画布 ≤ 49\"）、BAHOM 榉木 A 字架、KINGART 65\" 松木、Falling in Art 65\"",
   price:"US $25–80", who:"成人初学者、家用", comp:"hi", compT:"高：白牌多",
   pain:"伸高后晃；翼形螺母拧不紧、滑丝；说明书差", ev:["cheapWobble","viswinA"], evl:"部分来源",
   fig:{k:"stand",v:"aframe"},
   ex:[["somimeA","榉木，画布 ≤ 36\"，后支腿防倒"],["viswinA","65–89\"，画布 ≤ 49\"，零件有编号贴纸"],["bahomA","榉木 A 字架，带笔槽"],["kingart65","松木，< 2 lbs，画布 ≤ 40\""]],
   map:[["结构类型","A 字架"],["材质","松木 / 榉木"],["最大画布高度","≤ 36\" / 37–50\"","s"],["调节方式","翼形螺母"],["稳定结构","三点着地 + 后支腿"],["便携","可折叠收纳"],["产品等级","入门（松木、铁） / 中级（榉木 A 字 / H 架）"]],
   pros:["便宜、轻","可折叠"], cons:["伸高后晃","螺母调节慢、易滑丝"],
   up:["棘轮 / 卡槽免工具调节","加宽底座"], verdict:["可做","对应机会 B“免工具快调、稳固的 A 字架”。"],
   must:["写明承重","零件编号 + 图示说明"], plus:["棘轮调节"], avoid:["只写“sturdy”不给数字"]}
 ]},
 {g:"H 架", about:"画室主力", items:[
  {t:"榉木 H 架画室架", vol:"主流", volWhy:"MEEDEN、Creative Mark、Somime、DJAR 多款在售，画布可到 77–78\"。",
   combo:["H 架","榉木","画布 51–78\"","前后倾斜","承重 33 lbs"],
   rep:"MEEDEN 多功能 H 架（画布 ≤ 77\"，承重 33 lbs）、Creative Mark Carolina（60–102\"，24 lbs，整装）、Somime H 架（≤ 78\"）、DJAR 大号 H 架",
   price:"US $90–250", who:"进阶爱好者、专业画家", comp:"hi", compT:"高：品牌 + 白牌",
   pain:"重、占地；需组装；价格较高", ev:["meedenH","carolina"], evl:"有来源",
   fig:{k:"stand",v:"hframe"},
   ex:[["meedenMulti","画布 ≤ 77\"，承重 33 lbs，可放 2 幅"],["carolina","60–102\"，24 lbs，整装发货"],["somimeH","画布 ≤ 78\""],["djarH","榉木，画布 ≤ 78\""]],
   map:[["结构类型","H 架"],["材质","榉木"],["最大画布高度","51–77\" / 78\" 以上","s"],["承重","15–33 lbs","s"],["整架重量","10–25 lbs","m"],["同时放画数","2 幅（上下）","s"],["产品等级","中级（榉木 A 字 / H 架）"]],
   pros:["稳","画幅大"], cons:["重","价格高"], up:["平价段（$70–100）稳固款"], verdict:["谨慎","品牌和白牌都多；平价稳固款见 ③（C）。"],
   must:["写明承重和整架重量"], plus:["带轮"], avoid:["—"]},
  {t:"重型摇柄 H 架", vol:"小众", volWhy:"U.S. Art Supply 摇柄重型 H 架、重型加大 H 架（35 lbs）在售。",
   combo:["摇柄 H 架","榉木","画布 78\" 以上","摇柄","带锁万向轮"],
   rep:"U.S. Art Supply Double Rocker Crank 重型 H 架、U.S. Art Supply 重型加大 H 架（带锁轮，35 lbs）",
   price:"US $200–500", who:"专业画家、大幅作画", comp:"lo", compT:"低：少数品牌",
   pain:"贵、重", ev:["usasCrank"], evl:"有来源",
   fig:{k:"stand",v:"crank"},
   ex:[["usasCrank","摇柄升降，重型"],["usasHeavy","带锁万向轮，35 lbs"]],
   map:[["结构类型","摇柄 H 架"],["调节方式","摇柄"],["稳定结构","带锁万向轮"],["整架重量","25 lbs 以上","m"],["产品等级","专业（重型、摇柄）"]],
   pros:["大画幅调节省力"], cons:["贵"], up:["—"], verdict:["不建议","需求小、客单高、运输重。"], must:["—"], plus:["—"], avoid:["—"]},
  {t:"可平放多功能画室架", vol:"细分", volWhy:"MEEDEN Versatile、多款 H 架写明“可放平”（tilting flat）。",
   combo:["可平放多功能架","榉木","可放平（0°）","画布 ≤ 77\""],
   rep:"MEEDEN Versatile H 架（59–95\"，可倾斜到放平）、可放 2 幅的 H 架（tilting flat）",
   price:"US $120–250", who:"水彩、素描、多媒介画家", comp:"mid", compT:"中",
   pain:"贵；放平后高度和稳定性受限", ev:["meedenV"], evl:"有来源",
   fig:{k:"stand",v:"flat"},
   ex:[["meedenV","59–95\"，可倾斜到放平"],["hTilt","可放 2 幅，可放平"]],
   map:[["结构类型","可平放多功能架"],["角度调节","可放平（0°）","m"],["使用场景","水彩 / 素描（需放平）"]],
   pros:["一架多用"], cons:["贵"], up:["—"], verdict:["谨慎","已有品牌覆盖（③ 中“可平放落地水彩架”已排除）。"], must:["—"], plus:["—"], avoid:["—"]},
  {t:"带抽屉画室架", vol:"细分", volWhy:"ARTIFY H 架带抽屉和层板（75\"）、Stuelloaf 带抽屉款在售。",
   combo:["带抽屉画室架","榉木 / 松木","抽屉 / 层板","画布 ≤ 36–48\""],
   rep:"ARTIFY 榉木 H 架 + 抽屉 + 层板（≤ 75\"）、Stuelloaf 带抽屉款（画布 ≤ 36\"）",
   price:"US $80–200", who:"家用画室、小空间", comp:"mid", compT:"中",
   pain:"带抽屉的款式画布尺寸小（Stuelloaf ≤ 36\"）；收纳量有限", ev:["artifyLink"], evl:"有来源",
   fig:{k:"stand",v:"easelcab"},
   ex:[["artify","H 架 + 抽屉 + 层板，可调到 75\""],["easelDrawerSearch","搜索页：带抽屉画架"]],
   map:[["结构类型","带抽屉画室架"],["收纳配件","抽屉 / 层板"],["最大画布高度","≤ 36\" / 37–50\""],["使用场景","小户型家用"]],
   pros:["画架和收纳合一"], cons:["收纳量小","画幅受限"], up:["画架 + 完整收纳柜（见画柜）"], verdict:["谨慎","对应 ③ C“落地画架 + 收纳柜一体”。"], must:["—"], plus:["带轮"], avoid:["—"]}
 ]},
 {g:"国内美术生", about:"铁画架 / 木画架 + 画板", items:[
  {t:"国内美术生画架（铁 / 木 + 画板）", vol:"主流", volWhy:"国内画室、艺考素描常用可折叠铁画架、松木画架，常和 4K / 8K 画板一起卖（京东多款在售）。",
   combo:["铁画架 / A 字架","铁 / 松木","画架 + 画板","可折叠"],
   rep:"可升降折叠铁画架、松木三脚画架 + 4K 画板套装（京东多店铺）",
   price:"¥40–200", who:"美术生、画室", comp:"hi", compT:"高：价格低、店铺多",
   pain:"铁画架晃、生锈；画板变形", ev:["jdEasel"], evl:"部分来源",
   fig:{k:"stand",v:"cn"},
   ex:[["jdEasel","京东：美术生画架"],["jdEaselBoard","京东：画架 + 画板套装"]],
   map:[["结构类型","铁画架 / A 字架"],["材质","铁 / 钢 / 松木"],["销售组合","画架 + 画板"],["使用场景","艺考素描"],["目标人群","美术生"]],
   pros:["国内需求大"], cons:["价格低"], up:["—"], verdict:["谨慎","价格战。"], must:["—"], plus:["—"], avoid:["—"]}
 ]}
],

opps:[
 {t:"免工具快调、稳固的 A 字架", gap:"痛点缺口", score:{d:3,c:3,x:4,s:4,p:3,e:2},
  why:"A 字架是入门主力，常见抱怨是伸高后晃、翼形螺母拧不紧、说明书差。在售白牌多用翼形螺母，很少把“免工具快调 + 稳”当主卖点。",
  spec:["A 字架","榉木","棘轮 / 卡槽调节","加宽后支腿","画布 ≤ 48\"","写明承重"],
  diff:"视频演示一手调高度、拍画不晃", price:"US $45–65",
  risk:"结构改动需开模；卖点要靠视频才能看懂", verify:"抓 A 字架 Top 20 差评里 wobbly / knob / stripped / instructions 的占比",
  from:"木质 A 字画架（松木 / 榉木）", ev:["cheapWobble","viswinA"], evl:"部分来源"},
 {t:"平价稳固 H 架（$70–100）", gap:"价格带缺口", score:{d:3,c:2,x:3,s:4,p:3,e:3},
  why:"榉木 H 架稳，但多在 $90 以上；更便宜的 A 字架又晃。$70–100 的 H 架如果写清承重和稳定性，可能接住从 A 字架升级的人。",
  spec:["H 架","榉木 / 硬木","画布 ≤ 60\"","承重 ≥ 25 lbs","前后倾斜"], diff:"承重、稳定性写成数字对比", price:"US $70–100",
  risk:"MEEDEN 等已有覆盖；运费高", verify:"按 $70–100 价格段筛 h frame easel，看 Top 30 的数量和评分",
  from:"榉木 H 架画室架、木质 A 字画架（松木 / 榉木）", ev:["meedenH","cheapWobble"], evl:"部分来源"},
 {t:"落地画架 + 收纳柜一体（小空间画室）", gap:"场景缺口", score:{d:3,c:3,x:3,s:3,p:3,e:2},
  why:"带抽屉的画室架收纳量小、画幅受限（Stuelloaf ≤ 36\"）；真正“画架 + 收纳柜”一体的只有个别描述简单的款。小户型家用画室需要画架和颜料收纳合在一起。",
  spec:["H 架","下部 3 抽屉柜","带锁轮","画布 ≤ 48\""], diff:"一个占地解决画架和收纳", price:"US $150–220",
  risk:"体积大、运费高；需要做好稳定性", verify:"拉 easel with storage 的搜索量；看 ARTIFY 等带抽屉款的评论数",
  from:"带抽屉画室架", ev:["artifyLink","easelCabLink"], evl:"部分来源"},
 {t:"小户型可壁挂 / 折叠画室架", state:"clue", gap:"场景缺口",
  why:"小户型用户常抱怨画架占地，但没有找到直接证据说明壁挂 / 折叠画室架的需求量。",
  spec:["壁挂或折叠","承重 ≥ 20 lbs"], verify:"拉 wall mounted easel、folding studio easel 的搜索量", from:"榉木 H 架画室架", ev:["meedenH"], evl:"经验判断"},
 {t:"可平放的落地水彩画架", state:"out", gap:"场景缺口",
  why:"最初判断落地画架多数只能竖着放，水彩、素描需要能放平的落地架。",
  outWhy:"核实后 MEEDEN Versatile 等多款 H 架写明可倾斜到放平（tilting flat），已有人做。",
  spec:["可平放多功能架"], from:"可平放多功能画室架", ev:["meedenV"], evl:"有来源"}
],

grids:[
 {id:"canvas",name:"结构 × 最大画布高度",q:"每种结构在哪个画幅上还没人做？",rowT:"结构类型",colT:"最大画布高度",
  cols:["≤ 36\"","37–50\"","51–77\"","78\" 以上"],
  rk:["a frame easel","h frame easel","crank easel","tilting flat easel","easel with storage drawer"], ck:["36 inch canvas","48 inch canvas","72 inch canvas","78 inch canvas"],
  rc:["A字 画架","H型 画架","升降 画架","可平放 画架","带抽屉 画架"], cc:["","","",""],
  rows:[
   ["A 字架",[["R3","Somime 等",{r:["somimeA","bahomA"],t:["木质 A 字画架（松木 / 榉木）"]}],["R3","VISWIN 49\"、KINGART 40\"",{r:["viswinA","kingart65"]}],["S1","—"],["X","—"]]],
   ["H 架",[["S1","—"],["S2","—"],["R3","MEEDEN 77\"",{r:["meedenMulti","carolina"],t:["榉木 H 架画室架"]}],["S2","DJAR、Somime 78\"",{r:["djarH","somimeH"]}]]],
   ["摇柄 H 架",[["X","—"],["X","—"],["S1","—"],["S1","U.S. Art Supply",{r:["usasCrank","usasHeavy"],t:["重型摇柄 H 架"]}]]],
   ["可平放",[["S1","—"],["S1","—"],["S2","MEEDEN Versatile",{r:["meedenV","hTilt"],t:["可平放多功能画室架"],o:"可平放的落地水彩画架"}],["X","—"]]],
   ["带抽屉",[["S2","Stuelloaf ≤ 36\"",{r:["easelDrawerSearch"]}],["L2","画幅更大的带收纳款少",{r:["artify"],o:"落地画架 + 收纳柜一体（小空间画室）",ev:"部分来源"}],["S1","ARTIFY 75\"",{r:["artify"],t:["带抽屉画室架"]}],["X","—"]]]]},

 {id:"price",name:"结构 × 价格带",q:"每种结构在哪个价位还空着？",rowT:"结构类型",colT:"售价（美国站）",
  cols:["< $40","$40–80","$80–150","$150+"], price:["0-4000","4000-8000","8000-15000","15000-100000"],
  rk:["a frame easel","h frame easel","crank easel","easel with storage"],
  rc:["A字 画架","H型 画架","升降 画架","带抽屉 画架"], cc:["","","",""],
  rows:[
   ["A 字架",[["R3","松木款",{r:["kingart65"]}],["R3","榉木款",{r:["somimeA","viswinA","bahomA"]}],["S1","—"],["X","—"]]],
   ["H 架",[["X","—"],["L2","稳固的平价 H 架少",{o:"平价稳固 H 架（$70–100）",ev:"部分来源"}],["R3","MEEDEN、Somime、DJAR",{r:["meedenMulti","somimeH","djarH"]}],["S2","Creative Mark",{r:["carolina"]}]]],
   ["摇柄 H 架",[["X","—"],["X","—"],["X","—"],["S2","U.S. Art Supply",{r:["usasCrank","usasHeavy"]}]]],
   ["带收纳",[["X","—"],["S1","—",{r:["easelDrawerSearch"]}],["S2","ARTIFY",{r:["artify"]}],["L2","画架 + 收纳柜一体少",{o:"落地画架 + 收纳柜一体（小空间画室）",ev:"部分来源"}]]]]},

 {id:"adjust",name:"结构 × 调节方式",q:"每种结构用什么方式调节，有没有更快的？",rowT:"结构类型",colT:"调节方式",
  cols:["翼形螺母","棘轮 / 卡槽","摇柄"],
  rk:["a frame easel","h frame easel","studio easel"], ck:["wing nut","ratchet","crank"],
  rc:["A字 画架","H型 画架","画室 画架"], cc:["螺母","卡槽","摇柄"],
  rows:[
   ["A 字架",[["R3","多数白牌",{r:["somimeA","viswinA"]}],["L3","免工具快调的 A 字架少",{o:"免工具快调、稳固的 A 字架",ev:"部分来源"}],["X","—"]]],
   ["H 架",[["S3","—",{r:["djarH"]}],["S2","MEEDEN 卡槽",{r:["meedenMulti"]}],["S1","U.S. Art Supply",{r:["usasCrank"]}]]],
   ["铁画架",[["S3","国内多数",{r:["jdEasel"]}],["S1","—"],["X","—"]]]]},

 {id:"scene",name:"使用场景 × 关键卖点",q:"每个场景最在意的卖点，有没有产品明确满足？",rowT:"使用场景",colT:"关键卖点",
  cols:["稳不晃","大画幅","可放平","免工具调节","收纳","可折叠"],
  rk:["studio easel","watercolor easel","art student easel","small space easel","beginner easel"], ck:["sturdy","large canvas","tilt flat","easy adjust","storage","foldable"],
  rc:["画室 画架","水彩 画架","美术生 画架","小户型 画架","入门 画架"], cc:["稳","大画幅","放平","调节","收纳","折叠"],
  rows:[
   ["画室油画 / 丙烯",[["S3","H 架",{r:["meedenMulti","carolina"]}],["S3","—",{r:["somimeH"]}],["S1","—"],["L2","—",{o:"免工具快调、稳固的 A 字架"}],["S1","—"],["S1","—"]]],
   ["水彩 / 素描",[["S2","—"],["S1","—"],["S2","MEEDEN Versatile",{r:["meedenV"]}],["S1","—"],["S1","—"],["S1","—"]]],
   ["艺考素描",[["L2","铁画架晃",{r:["jdEasel"]}],["S1","—"],["X","—"],["S1","—"],["X","—"],["S3","—",{r:["jdEaselBoard"]}]]],
   ["小户型家用",[["S2","—"],["X","—"],["S1","—"],["S1","—"],["L3","画架和收纳分开买",{r:["artify"],o:"落地画架 + 收纳柜一体（小空间画室）",ev:"部分来源"}],["L1","—",{o:"小户型可壁挂 / 折叠画室架",clue:true}]]],
   ["入门家用",[["L3","A 字架伸高会晃",{r:["somimeA","viswinA"],o:"免工具快调、稳固的 A 字架",ev:"部分来源"}],["S1","—"],["S1","—"],["L2","—",{o:"免工具快调、稳固的 A 字架"}],["S1","—"],["S3","—",{r:["kingart65"]}]]]]}
],

refs:{
 somimeA:["Somime 榉木 A 字架（≤ 36\"）","https://www.amazon.com/dp/B0FHK9F9D4"], viswinA:["VISWIN 可倾斜 A 字架（≤ 49\"）","https://www.amazon.com/dp/B0912WFYJS"], bahomA:["BAHOM 榉木 A 字架","https://www.amazon.com/clp/B08G46V6YC"], kingart65:["KINGART 65\" 松木 A 字架","https://www.amazon.com/dp/B07HYKWZBX"],
 meedenMulti:["MEEDEN 多功能 H 架（≤ 77\"）","https://www.amazon.com/dp/B07YTGGY8S"], meedenV:["MEEDEN Versatile H 架（可放平）","https://www.amazon.com/dp/B07R5RHWVT"], hTilt:["可放 2 幅、可放平的 H 架","https://us.amazon.com/dp/B0GX8YQTQC"],
 carolina:["Creative Mark Carolina H 架","https://www.amazon.com/dp/B0049V3COC"], somimeH:["Somime H 架（≤ 78\"）","https://www.amazon.com/clp/B0D52FT8WF"], djarH:["DJAR 大号榉木 H 架","https://www.amazon.com/clp/B0DRF7Y8XL"],
 usasCrank:["U.S. Art Supply 摇柄重型 H 架","https://www.amazon.com/clp/B00OU1A7OO"], usasHeavy:["U.S. Art Supply 重型加大 H 架","https://www.amazon.com/dp/B00L5NYIKO"],
 artify:["ARTIFY H 架 + 抽屉 + 层板","https://www.amazon.com/clp/B0BY1R1Y4D"], easelDrawerSearch:["Amazon 搜索：easel with drawer","https://www.amazon.com/easel-drawer/s?k=easel+with+drawer"],
 jdEasel:["京东 · 美术生画架（搜索页）","https://search.jd.com/Search?keyword=%E7%BE%8E%E6%9C%AF%E7%94%9F%E7%94%BB%E6%9E%B6&enc=utf-8"], jdEaselBoard:["京东 · 画架画板套装（搜索页）","https://search.jd.com/Search?keyword=%E7%94%BB%E6%9E%B6%E7%94%BB%E6%9D%BF%E5%A5%97%E8%A3%85&enc=utf-8"]
},

src:{
 cheapWobble:["Virtual Art Academy / 零售评论：廉价画架伸高后晃、螺母和说明书问题","https://www.virtualartacademy.com/winsor-newton-easel/"],
 viswinA:["VISWIN A 字架（Amazon，零件编号贴纸）","https://www.amazon.com/dp/B0912WFYJS"],
 meedenH:["MEEDEN 多功能 H 架（Amazon，承重 33 lbs）","https://www.amazon.com/dp/B07YTGGY8S"],
 carolina:["Creative Mark Carolina（Amazon）","https://www.amazon.com/dp/B0049V3COC"],
 usasCrank:["U.S. Art Supply 摇柄 H 架（Amazon）","https://www.amazon.com/clp/B00OU1A7OO"],
 meedenV:["MEEDEN Versatile（Amazon，可放平）","https://www.amazon.com/dp/B07R5RHWVT"],
 artifyLink:["ARTIFY 带抽屉 H 架（Amazon）","https://www.amazon.com/clp/B0BY1R1Y4D"],
 easelCabLink:["Amazon：画架 + 收纳柜款（描述简单）","https://www.amazon.com/dp/B0DCG5FSK9"],
 jdEasel:["京东 · 美术生画架（搜索页）","https://search.jd.com/Search?keyword=%E7%BE%8E%E6%9C%AF%E7%94%9F%E7%94%BB%E6%9E%B6&enc=utf-8"]
}
});
